#include <bits/stdc++.h>
#define mx 100000
#define ll long long
#define f(i,a,b) for(i=a;i<b;i++)

using namespace std;

// Will use c to count actual number of partitions
int dp[mx], c=0;

void PartitionCalculation(int idx, int val, int maxVal)
{
    int i=0;
    if (val== 0){
        f(i,1,idx)
            cout<<dp[i]<<" ";
        cout<<endl;
        c++;}
    else{
        for(i=maxVal; i>=1; i--){
            if (i>val)
                continue;
            else{
                dp[idx] = i;
                PartitionCalculation( idx+1, val-i, i);}
        }
    }
    return ;
}

int main()
{
    int n;
        cout<<"Enter a number of coins 1-10 to find its number of partitions: "; //asking for user input
        cin>>n;
        c=0;
        cout<<"Partitions: "<<endl;
        PartitionCalculation(1, n, n); //use calculation from above to find # of partitions
        cout<<"Total # of ways that the coins can be separated into piles : "<<c<<endl; //display results.
    return 0;
}
