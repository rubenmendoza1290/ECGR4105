#include <iostream>
using namespace std;

void printArr(int p[], int m)
{
   for (int i = 0; i < m; i++)
      cout << p[i] << " ";
   cout << endl;
}
void partitionCalculation(int m)
{
   int p[m];
   int k = 0;
   p[k] = m;
   while (true)
   {
      printArr(p, k + 1);
      int val = 0;
      while (k >= 0 && p[k] == 1)
      {
         val += p[k];
         k--;
      }
      if (k < 0)
         return;
         p[k]--;
         val++;
      while (val > p[k])
      {
         p[k + 1] = p[k];
         val = val - p[k];
         k++;
      }
      p[k + 1] = val;
      k++;
   }
}
int main() {
   int n;
   cout << "ENTER A NUMBER 1-10 TO FIND ITS PARTITION P(N):\n";
   cin >> n ;
   partitionCalculation(n);
   return 0;
}