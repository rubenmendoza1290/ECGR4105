#include<iostream>      //Basic Header/Compiler info.
using namespace std;

int main()
{
   int x, s = 0, t,fact=1, count=0;  //Introducing integers being used.
   cout << "Enter a number to find its factorial and sum of digits : ";    //Asking for user to input number they'd like to get factorial of.
   cin>> x; //looking for user input.
   for(t=1;t<=x;t++){    //Solving for the factorial of user inputed number.
      fact=fact*t;
  }
  cout<<"Factorial of " <<x<<" is: "<<fact<<endl;  //Displaying result of factorial.
   while (fact != 0) {
      s = s + fact % 10; //While loop to solve for the sum of digits in factorial answer.
      fact = fact / 10;
   }
   cout << "The sum of the digits : " << s << endl; //Display sum of the factorial's digits.
   return 0;
}