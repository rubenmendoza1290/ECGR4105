#include <iostream>     //Basic Header/Compiler info
using namespace std;

int main()
{
    //User is asked to input two numbers to find their GCD
    cout << "Please enter 2 numbers to find their greatest common divisor or GCD" << endl;
    //Intergers used in code
    int n1, n2, a, b, L, s, temp, gcd;
    //Cin takes user input
    cin >> n1 >> n2;
    //Incase user inputs a negative number, take absolute value of them:
    a = abs(n1), b = abs(n2);
    //If any number entered is 0 then display error message
    if(a == 0 || b == 0)
        cout << "Error; Cannot Divide by zero" << endl;
    //else, continue with finding GCD
    else
    {
        //Finds the larger number
        if (a >= b)
        L = a, s = b;
        else
        L = a, s = b;
            //GCD while loop
            while(s!=0)
            {
                temp=s;
                s=L%s;
                L=temp;
            }
            gcd=L;
            //Displaying final result:
            cout << "Greatest Common Divisor is: " << gcd << endl;
    }
    
    return 0;
    
}