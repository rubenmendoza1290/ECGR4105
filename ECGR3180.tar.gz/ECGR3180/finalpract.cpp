#include <iostream>
#include <string>
#include <utility>

class Node
{
private:
    int key;
    std::string val;
    Node* left;
    Node* right;
    friend class BinarySearchTree;
};

class BinarySearchTree
{
public:
    BinarySearchTree(): root{nullptr} {}
    void insert(int key, std::string val); // Recursive
    std::pair<int, std::string> min(); // Returns the min key, and associated value
    int nodeCount(); // Returns the number of nodes
    
    /* A Helper method(Based on Preorder Transversal) to count the nodes */
    int nodeCountHelper(Node* current);
private:
    Node* root;
    void insertHelper(Node* parent, Node* new_node);
};

void BinarySearchTree::insert(int key, std::string val)
{
    Node* new_node = new Node;
    new_node->key = key;
    new_node->val = val;
    new_node->left = nullptr;
    new_node->right = nullptr;
    if (root == nullptr) {
        root = new_node;
    } else {
        insertHelper(root, new_node);
    }
}

void BinarySearchTree::insertHelper(Node* parent, Node* new_node)
{
    if (new_node->key < parent->key) {
        if (parent->left == nullptr) {
            parent->left = new_node;
        }
        else {
            insertHelper(parent->left, new_node);
        }
    }
    else if (new_node->key > parent->key) {
        if (parent->right == nullptr) {
            parent->right = new_node;
        }
        else {
            insertHelper(parent->right, new_node);
        }
    }
}

std::pair<int, std::string> BinarySearchTree::min() {
    Node* current = root;
    while (current->left != nullptr) {
        current = current->left;
    }
    return std::make_pair(current->key, current->val);
}

//Based on Preorder Transversal
int BinarySearchTree::nodeCountHelper(Node* current) {
    if (current == nullptr) {
        return 0;
    }
    return 1 + nodeCountHelper(current->left) + nodeCountHelper(current->right);
}

int BinarySearchTree::nodeCount() {
    return nodeCountHelper(root);
}

// Test
int main()
{
    BinarySearchTree t;
    t.insert(5, "Boron");
    t.insert(3, "Lithium");
    t.insert(7, "Nitrogen");
    t.insert(2, "Helium");
    t.insert(4, "Berylium");
    t.insert(6, "Carbon");
    t.insert(8, "Oxygen");
    auto minPair = t.min();
    std::cout << "Min key and value: " << minPair.first << " " << minPair.second << std::endl;
    std::cout << "Number of nodes: " << t.nodeCount() << std::endl;

}