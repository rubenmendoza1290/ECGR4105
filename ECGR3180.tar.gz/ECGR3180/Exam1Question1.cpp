// For an input string of words, find the most frequently occuring word. In case of ties, report any one of them. 
// Your algorithm should be O(n) time where n is the number of words in the string
#include <iostream>
#include <vector>
#include <sstream>
#include <unordered_map>
#include <algorithm>
using namespace std;
string findWord(vector<string>& tokens);
 
int main() {
string line = "I felt happy because I saw the others were happy and because I knew I should feel happy but I wasn’t really happy";
// Convert string to a vector of words
char delimiter = ' ';
string token;
istringstream tokenStream(line);
vector<string> tokens;
while (getline(tokenStream, token, delimiter)) {
tokens.push_back(token);
}
cout << "The most frequently occuring word is: " << findWord(tokens) << endl;
}
string findWord(vector<string>& tokens) {
// Your code here
vector<int> TokCount;
vector<string> Tok;

// Iterate through tokens
for (int i = 0; i < tokens.size(); i++)
{
    auto it = std::find(Tok.begin(), Tok.end(), tokens[i]);
// if the token not found in Tok
    if (it == Tok.end())
    {
    Tok.push_back(tokens[i]);
    TokCount.push_back(1);
    } else
    {
        //if token found, increase count by one
        auto index = std::distance(Tok.begin(), it);
        TokCount[index] = TokCount[index] + 1;
    }
}
int maxI = 0;
for (int i = 0; i < TokCount.size(); i++) 
{
    if(TokCount[maxI] < TokCount[i])
    maxI = i;
}

// return the corresponding word
return Tok[maxI];
}