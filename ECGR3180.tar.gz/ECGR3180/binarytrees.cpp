#include <iostream>
using namespace std;


struct Node {
    int data;
    Node* left; //left and right child
    Node* right;
    
    
};

//to add new node:
Node* createNewNode(int data) {
    /*4 steps:
    1. create new node
    2. set data
    3. take care of left and right child nodes which will initially be null when creating parent node
    4. need to have a reference to node incase want to add children later
    */
    
    Node* newNode = new Node(); //creating new Node
    newNode->data = data; //set value to node
    newNode->left = newNode -> right = nullptr; //left and right child initially null
    return newNode; //reference to node just added to outside of this function, whoever invokes will receievce refeerence to newly added node
    
}

int main(){
    //Level 1
    Node* root=createNode(1);
    //Level 2
    root->left= createNewNode(2);
    root->right= createNewNode(3);
    //Level 3
    root ->left->left=createNode(4);
    root ->left->right=createNode(5);
    root ->right->left=createNode(6);
    root ->right->right=createNode(7);
    //Level 4
    root ->left->right->left=createNode(9);
    root ->right->right->left=createNode(15);
    
    
    cin.get();
}
























/*
#include <iostream>
using namespace std;


struct Node {
    int data;
    Node* left; //left and right child
    Node* right;
    
    
};

//to add new node:
Node* createNewNode(int data) {
    //4 steps:
    //1. create new node
    //2. set data
    //3. take care of left and right child nodes which will initially be null when creating parent node
    //4. need to have a reference to node incase want to add children later
    
    Node* newNode = new Node(); //creating new Node
    newNode->data = data; //set value to node
    newNode->left = newNode -> right = nullptr; //left and right child initially null
    return newNode; //reference to node just added to outside of this function, whoever invokes will receievce refeerence to newly added node
    
}

int main(){
    //create root node
    Node* root=createNode(1);
    //how to add left and right child to this root node?
    //left child:
    root->left= createNewNode(2);
    //right child:
    root->right= createNode(3);
    
    //to add 4 into 1-2-4:
    root ->left->left=createNode(4);
    
    
    cin.get();
}
*/