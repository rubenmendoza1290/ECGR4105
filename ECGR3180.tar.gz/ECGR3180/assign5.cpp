/* 
Write a function that returns if a string of paranthesis are matched. 
You are required to use the STL stack datastructure in your code for O(n) time complexity.
See 5.17 in the book for problem description and a stack based algorithm. 
*/
#include <iostream>
#include <stack>
#include <vector>

using namespace std; 
  
// function to check if paranthesis are balanced 
bool areParanthesisBalanced(string expr) { 
    // Your code here
    stack<char> x;
    for (int i = 0; i < expr.length(); i++) {
        if (x.empty()) {
            x.push(expr[i]);
        }
        else if ((x.top() == '[' && expr[i] == ']') || (x.top() == '{' && expr[i] == '}') || (x.top() == '(' && expr[i] == ')')) {
            x.pop();
        }
        else {
            x.push(expr[i]);
        }
    }
    if (x.empty()) {
        return true;
    }
    return false;
}
  
// Test - DO NOT MODIFY
int main() 
{ 
    vector<string> parans = {"{()}[]", "[[", "))", "{[()]}", "({[])}"}; 
  	
	for(auto expr : parans) {
    	if (areParanthesisBalanced(expr)) 
        	cout << "Balanced" << endl; 
    	else
        	cout << "Not Balanced" << endl;
	} 
    return 0; 
}
