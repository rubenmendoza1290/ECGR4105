/*
Leetcode Problem 242 - Valid Anagram
 Given two strings s and t, return true if t is an anagram of s, and false 
otherwise.
An Anagram is a word or phrase formed by rearranging the letters of a different 
word or phrase,
typically using all the original letters exactly once.
Example 1:
Input: s = "anagram", t = "nagaram"
Output: true
Example 2:
Input: s = "rat", t = "car"
Output: false
Constraints:
1 <= s.length, t.length <= 5 * 104
s and t consist of lowercase English letters.
NOTE: Your code has to run in O(n) time where n is the number of letters. 
Zero points for any non-O(n) algorithm.
*/
#include <iostream>
#include <unordered_map>
#include <vector>

using namespace std;

bool isAnagram(string s, string t);

int main() {
    string s = "anagram";
    string t = "nagaram";
    if (isAnagram(s, t))
        cout << "True" << endl;
    else 
        cout << "False" << endl;
    s = "rat";
    t = "car";
    if (isAnagram(s, t))
        cout << "True" << endl;
    else 
        cout << "False" << endl;
}

bool isAnagram(string s, string t) {
// Your code here
// match size of arrays first make sure they have same amount of letters
    if (t.size() != s.size()){
        return false;
    }
    // hash map
    vector<int> count(26);
    // for loop to check each letter
    for (int i = 0; i < t.size(); i++){
        count[t[i] - 'a']++;
    }
    for (int x = 0; x < s.size(); x++){
        count[s[x] - 'a']--;
        if (count[s[x] - 'a'] < 0){
            return false;
        }
    }
    return true;
}