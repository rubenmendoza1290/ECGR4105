




















































//special method that is called when a class is instatiated into an object
User user 1;
//there will be a method call to the constructor defined inside class^
//when u create class such as User you dont have to create constructor function
//but still make a user
//constructor created implicitly i.e. automatically be created for us
//but, does absolute bare minimum required to create new user
//if we want to do anything extre, need to explicitly create method and type out exactly what we want it to do
//exact same name as class
//no return or return type
User () //DEFAULT CONSTRUCTOR (no number inside)
{
    //code
}
//can create some that have parameters
//so we can call a different constructor
//ex:
User user1 ("Caleb", "Curry");//first, last name
//default constructor^ will not get hit, instead this one below
//will call:
User(std::string f, std::string l)
{
    //code
    //take parameters and assign them to class members
    //class has members like "first name" and "last name"
    first_name = f;
    last_name = l;
    //implicitly defined constructor will automatically create by itself only if you dont make a custom constructor
    //if i wanted a default constructor to not require first and last name, can do
}
User()
{
    //code
}
//destructor
//will automatically destruct
//but you might want to override for an output, logging, or to clean something up
//do everything like consturcot but use ~
~User()
{
    //code
    std::cout << "destroyed" << endl;
}