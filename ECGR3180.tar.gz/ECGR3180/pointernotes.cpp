#include <iostream>
#include <string>

using namespace std;
//playing with pointers in c++ is really fun

int main {
 int a = 44;
 // A pointer points to some variable, that is, it stores the address of a variable.
 //E.g.- if 'a' has an address 0xffff377c, then the pointer to 'a' will store a value 0xffff377c in it.
 //Address in C++ is "&a" read as "address of a"
 
 int *b; // Decleration of pointer b
 // b will store the address of an integer
 b = &a; // Storing address of a in b
 
 // "*b" is the value 'b' points to, 44
 // 'int *b;' means '*b' is an integer but '*' BEFORE means that b is a pointer
 // '*b' is the value of the variable to which 'b' is pointing
 /*

int a; - 'a' is an integer.
int *b; - 'b' is a pointer to an integer.
b = &a - 'b' is now pointing to 'a'(value of 'b' is the address of 'a').
'*b' will now represent a (value of '*b' is the value of 'a').
 
 */
 
    return 0;
}

/*

int main(){
    
	int a = 10;
  	int *p;
  	p = &a;
  	cout << "p = " << p << endl;
  	cout << "*p = " << *p << endl;
  	cout << "&p = " << &p << endl;
  	cout << "*&p = " << *&p << endl;
  	cout << "&a = " << &a << endl;
  	
	return 0;
}

will output:

p = 0x7ffc7ba7ac6c
*p = 10
&p = 0x7ffc7ba7ac60
*&p = 0x7ffc7ba7ac6c
&a = 0x7ffc7ba7ac6c

*/


// Passing Pointers to Function:

/*

void swap( int *a, int *b )
{
	int t;
	t = *a;
	*a = *b;
	*b = t;
}

int main(){
	int num1, num2;
	cout << "Enter first number" << endl;
	cin >> num1;
	cout << "Enter second number" << endl;
	cin >> num2;
	swap( &num1, &num2);
	cout << "First number = " << num1 << endl;
	cout << "Second number = " << num2 << endl;
	return 0;
}

//output:

//Enter first number 
//2 
//Enter second number 
//4 
//First number = 4 
//Second number = 2


//we used call by reference in which we passed the address of num1 and num2 as the arguments to the function.
*/

/*

// Pointer to Arrays

int age[50];
int *p;
p = age;

// *p is the value of the first element of the array.
// So, *p is age[0], *(p+1) is age[1], *(p+2) is age[2].
// *age is age[0] ( value at age )

*/