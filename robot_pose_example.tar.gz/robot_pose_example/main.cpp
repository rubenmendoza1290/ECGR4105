#include <iostream>

using namespace std;

class Pose2d{
    public:
    double x;
    double y;
    double theta;
    
    Pose2d(double x = 0.0, double y = 0.0, double theta = 0.0){
        this->x = x;
        this->y = y;
        this->theta = theta;
}

Pose2d operator+(Pose2d pose){
    
    
    
    
    
    
    
    
    
    return Pose2d(x + pose.x, y + pose.y, theta + pose.theta);
}

Pose2d operator+(double i){
    return Pose2d(x + i, y +i, theta + i);
}

bool operator==(const Pose2d& pose){
    return this->x == pose.x && this->y == pose.y && this->theta == pose.theta;
}

};

int main(){
    Pose2d robotPose(1.0, 1.0, 90.0);
    Pose2d robotPose(1.0, 1.0, 90.0);
    
    robotPose.x = 1.0;
    robotPose2.x = 2.0;
    
    Pose2d robotPose3  = robotPose + 1.0;
    
    cout << robotPose3.x << " " << robotPose3.y << " " << robotPose3.theta << endl;
    
    bool isEqual = robotPose == robotPose2;
    cout << isEqual << endl;
    
    return 0;
}