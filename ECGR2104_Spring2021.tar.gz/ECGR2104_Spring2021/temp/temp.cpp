#include <iostream>
#include <fstream>

using namespace std;

int temp (){
 ofstream outFile;
 outFile.open("hello.txt");
 return 0;   
}