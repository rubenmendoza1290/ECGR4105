#include "lands.h"

string Lake::getShortDescription(){
    return "lake";
}

string Lake::getLongDescription(){
    
}