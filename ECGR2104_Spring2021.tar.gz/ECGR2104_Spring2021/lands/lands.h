#ifndef LANDS_H
#define LANDS_H

#include <string>

class Land {
    public:
    virtual string getShortDescription() = 0;
    virtual string getLongDescrpition() = 0;
    
    private:
    
};

class Lake : public Land {
    public:
    string getShortDescrpition();
    string getLongDescription();
    
    private:
};



#endif