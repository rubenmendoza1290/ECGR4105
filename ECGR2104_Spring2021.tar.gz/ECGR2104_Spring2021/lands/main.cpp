#include <iostream>
#include "lands.h"

using namespace std;

class Player {
    public:
    PLayer(unsigned int health, unsigned int hunger, unsigned int thirst, unsigned int x, unsigned int y){
        
    }










}

    private:
    unsigned int health;
    unsigned int hunger;
    unsigned int thirst;
    unsigned int x;
    unsigned int y;
};

int main(){
    const unsigned int MAP_SIZE = 20;
    Player player(3, 10, 5, MAP_SIZE/2, MAP_SIZE/2);
    
    //Build Map
    Land* map[MAP_SIZE][MAP_SIZE];
    for(int i = 0; i < MAP_SIZE; i++){
        for(int j = 0; j < MAP_SIZE; j++){
            map[i] = new Lake;
        }
    }
    cout << "You wake up in a " << map[player.getX()][player.getY()].getShortDescription << "with no memory of how you got there." <<endl;
    
    while(player.isAlive()){
        unsigned int x = player.getX();
        unsigned int y = player.getY();
        cout << "To the north you see a " << map[x][y + 1]->getShortDescription() << endl;
        cout << "To the south you see a " << map[x][y - 1]->getShortDescription() << endl;
        cout << "To the east you see a " << map[x + 1][y]->getShortDescription() << endl;
        cout << "To the west you see a " << map[x - 1][y]->getShortDescription() << endl;
    }
    
    return 0;
}