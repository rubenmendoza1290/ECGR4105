#include <iostream>
#include <string>
#include <vector>

using namespace std;
class Student{
    public:
    Student(string n){
        setName(n);
    }
    Student(string n, vector<double> cs){
        setName(n);
        for(int i = 0; i < cs.size(); i++){
            addClassScore(cs.at(i));
        }
    }
    void setName(string n){
        if(n.length() < 1){
            cout << "Invalid name!!" << endl;
            return;
        }
        name = n;
    }
    string getName() const{
        return name;
    }
    void addClassScore(double score){
        if(score < 0.0 || score > 4.0){
            cout << "Invalid score value: " << score << endl;
            return;
        }
        classScores.push_back(score);
        double sum = 0.0;
        for(int i = 0; i < classScores.size(); i++){
            sum += classScores.at(i);
        }
        gpa = sum / static_cast<double>(classScores.size());
    }
    double getGpa() const{
        return gpa;
    }
    private:
    string name;
    double gpa;
    vector<double> classScores;
};
int main(){
vector<double> classScores = {2.0, 2.1, 2.4, 5.1};
    Student s("Bob", classScores);
    cout << "Student Name: " << s.getName() << endl;
    cout << "GPA: " << s.getGpa() << endl;
    /*
    s.name = "Bob";
    s.gpa = 2.0;
    s.classScores.push_back(4.0);
    s.classScores.push_back(0.0);
    s.classScores.push_back(2.0);
    cout << "Student Name: " << s.name << endl;
    cout << "GPA: " << s.gpa << endl;
    for(int i = 0; i < s.classScores.size(); i++){
        cout << "Class " << i << " Score: " << s.classScores.at(i) << endl;
    }
    */
    return 0;
}