#ifndef FoodItem_H
#define FoodItem_H

#include <string>

using namespace std;

class FoodItem{
    private:
    string name;
    int Calories;
    int Fat;
    int Sugar;
    int Protein;
    int Sodium;
    int Calroies2;
    int Fat2;
    int Sugar2;
    int Protein2;
    int Sodium2;
    
    public:
    FoodItem(string n, int cal, int f, int s, int p, int sd);
    
    int getCalories();
    int getFat();
    int getSugar();
    int getProtein();
    int getSodium();
    int userInput();
    void totalCalories(int);
    void totalFat(int);
    void totalSugar(int);
    void totalProtein(int);
    void totalSodium(int);
    double getUserInput();
    
};

#endif