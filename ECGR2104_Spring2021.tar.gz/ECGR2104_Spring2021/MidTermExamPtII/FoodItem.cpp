#include "FoodItem.h"
#include <iostream>
#include <string>
using namespace std;

FoodItem::FoodItem(string n, int cal, int f, int s, int p, int sd)
{
    name = n;
    Calories = cal;
    Fat = f;
    Sugar = s;
    Protein = p;
    Sodium = sd;
}
void FoodItem::totalCalories(int Calories2){
    Calories = Calories + Calories2;
}
int FoodItem::getCalories() {
    return Calories;
}
void FoodItem::totalFat(int Fat2){
    Fat = Fat + Fat2;
}
int FoodItem::getFat() {
    return Fat;
}
void FoodItem::totalSugar(int Sugar2){
    Sugar = Sugar + Sugar2;
}
int FoodItem::getSugar() {
    return Sugar;
}
void FoodItem::totalProtein(int Protein2){
    Protein = Protein + Protein2;
}
int FoodItem::getProtein() {
    return Protein;
}
void FoodItem::totalSodium(int Sodium2){
    Sodium = Sodium + Sodium2;
}
int FoodItem::getSodium() {
    return Sodium;
}