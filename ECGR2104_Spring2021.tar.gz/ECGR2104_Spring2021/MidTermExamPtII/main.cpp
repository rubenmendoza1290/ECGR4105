#include <iostream>
#include "FoodItem.h"
#include <vector>
using namespace std;

int main(){
    int userInput = 0;
    FoodItem fi1("Apple", 95, 0.3, 19, 0.5, 2);
    FoodItem fi2("One Chicken Enchilada", 236, 6, 26, 20, 682);
    FoodItem fi3("One taco de Barbacoa", 66, 3.25, 0, 8.88, 46);
    FoodItem fi4("Soda", 150, 0.1, 33, 0.3, 14.7);
    FoodItem fi5("Egg", 90, 7, 0.2, 6, 95);
    FoodItem fi6("Slice of American Cheese", 104, 9, 0.6, 5, 468);
    FoodItem fi7("Slice of white bread", 79, 1, 1.5, 2.7, 147);
    FoodItem fi8("One cup of ham", 203, 8, 0, 29, 1684);
    FoodItem fi9("Twenty oz Sirlion Steak", 1380, 80, 0, 153, 320);
    FoodItem fi10("Medium serving size of french fries", 365, 17, 0.4, 4, 246);
    FoodItem total("Total", 0, 0, 0, 0, 0);
    
    cout << "Welcome to your very own Nutrion Tracker! \nPlease select your foods from the list below: \n1. Apple\n2. One Chicken Enchilada\n3. One taco de Barbacoa\n4. Soda\n5. Egg\n6. Slice of American Cheese\n7. Slice of white bread\n8. One cup of ham\n9. Twenty oz Sirlion Steak\n10. Medium serving size of french fries\n11. Done" << endl;
    
    while (userInput != 11){
        cin >> userInput;
        if(userInput == 1){
            total.totalCalories(fi1.getCalories());
            total.totalFat(fi1.getFat());
            total.totalSugar(fi1.getSugar());
            total.totalProtein(fi1.getProtein());
            total.totalSodium(fi1.getSodium());
        }
        else if(userInput == 2){
        total.totalCalories(fi2.getCalories());
            total.totalFat(fi2.getFat());
            total.totalSugar(fi2.getSugar());
            total.totalProtein(fi2.getProtein());
            total.totalSodium(fi2.getSodium());
        }
        else if(userInput == 3){
        total.totalCalories(fi3.getCalories());
            total.totalFat(fi3.getFat());
            total.totalSugar(fi3.getSugar());
            total.totalProtein(fi3.getProtein());
            total.totalSodium(fi3.getSodium());
        }
        else if(userInput == 4){
        total.totalCalories(fi4.getCalories());
            total.totalFat(fi4.getFat());
            total.totalSugar(fi4.getSugar());
            total.totalProtein(fi4.getProtein());
            total.totalSodium(fi4.getSodium());
        }
        else if(userInput == 5){
        total.totalCalories(fi5.getCalories());
            total.totalFat(fi5.getFat());
            total.totalSugar(fi5.getSugar());
            total.totalProtein(fi5.getProtein());
            total.totalSodium(fi5.getSodium());
        }
        else if(userInput == 6){
        total.totalCalories(fi6.getCalories());
            total.totalFat(fi6.getFat());
            total.totalSugar(fi6.getSugar());
            total.totalProtein(fi6.getProtein());
            total.totalSodium(fi6.getSodium());
        }
        else if(userInput == 7){
        total.totalCalories(fi7.getCalories());
            total.totalFat(fi7.getFat());
            total.totalSugar(fi7.getSugar());
            total.totalProtein(fi7.getProtein());
            total.totalSodium(fi7.getSodium());
        }
        else if(userInput == 8){
        total.totalCalories(fi8.getCalories());
            total.totalFat(fi8.getFat());
            total.totalSugar(fi8.getSugar());
            total.totalProtein(fi8.getProtein());
            total.totalSodium(fi8.getSodium());
        }
        else if(userInput == 9){
        total.totalCalories(fi9.getCalories());
            total.totalFat(fi9.getFat());
            total.totalSugar(fi9.getSugar());
            total.totalProtein(fi9.getProtein());
            total.totalSodium(fi9.getSodium());
        }
        else if(userInput == 10){
        total.totalCalories(fi10.getCalories());
            total.totalFat(fi10.getFat());
            total.totalSugar(fi10.getSugar());
            total.totalProtein(fi10.getProtein());
            total.totalSodium(fi10.getSodium());
        }
        else if(userInput == 11){
            cout << "Your total calories consumed are: " << total.getCalories() << " cal\nYour total fat consumed is: " << total.getFat() << " g\nYour total sugar consumed is: " << total.getSugar() << " g\nYour total protein consumed is: " << total.getProtein() << " g\nYour total sodium consumed is: " << total.getSodium() << " mg" << endl << endl;
        }
        else if(userInput > 1 or userInput > 11){
        cout << "Choose an option between 1 and 11!" << endl;
        }
    }
    if (total.getCalories() > 2000)
    cout << "You've surpassed the daily recommended caloric intake of 2000 calories" << endl;
    if (total.getFat() > 70)
    cout << "You've surpassed the daily recommended fat intake of 70 g" << endl;
    if  (total.getSugar() > 30)
    cout << "You've surpassed the daily recommended sugar intake of 30 g" << endl;
    if (total.getProtein() > 50)
    cout << "You've surpassed the daily recommended protein intake of 50 g" << endl;
    if (total.getSodium() > 2300)
    cout << "You've surpassed the daily recommended sodium intake of 2,300 mg" << endl;
}