#include <iostream>
#include "DoublyLinkedListClass.h"
using namespace std;

int main(){
    doublyList list;
    list.push(5);
    list.push(6);
    list.push(7);
    list.push(8);
    list.push(9);
    list.print();
    cout << "size = "<<list.size()<<endl;
    cout << "pop: " << list.pop() <<endl;
    list.print();
    cout << "size = "<<list.size()<<endl;
    cout << "pop: " << list.pop() <<endl;
    list.print();
    cout << "size = "<<list.size()<<endl;
    cout << "pop: " << list.pop() <<endl;
    list.print();
    cout << "pop: " << list.pop() <<endl;
    list.print();
    cout << "size = "<<list.size()<<endl;
    cout << "pop: " << list.pop() <<endl;
    list.print();
    cout << "size = "<<list.size()<<endl;
}