#ifndef DDL_H
#define DLL_H
#include<iostream>
#include<cstdio>
#include<cstdlib>

typedef struct Node
{
    int value;
    struct Node *next;
    struct Node *prev;
    int data;
}Node;

class doublyList
{
    Node *head;
    int count = 0;

public:
    doublyList();
    doublyList(int);
    void push(int);
    int pop();
    int size();
    void print();
    void insert(int dataToInsert, unsigned int index);
    void remove();
};
#endif