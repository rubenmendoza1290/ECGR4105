#include <iostream>
#include "DoublyLinkedListClass.h"

using namespace std;

doublyList::doublyList(){
    head = nullptr;
}


void doublyList::push(int data){
    Node *temp = new Node;
    temp->value = data;
    temp->prev = temp->next = nullptr;

    if(head == nullptr){
        head = temp;
    }else{
        Node *itr = head;
        while(itr->next){
            itr = itr->next;
        }
        temp->prev = itr;
        itr->next = temp;
    }
    count++;
}
int doublyList::pop(){
    Node *temp = head;
    while(temp->next){
        temp = temp->next;
    }
    int x = temp->value;
    if(temp == head){
        head = nullptr;
    }else{
        temp->prev->next = nullptr;
    }
    delete temp;
    count --;
    return x;
}
void doublyList::print(){
    Node *temp = head;
    while(temp){
        cout << temp->value <<" ";
        temp = temp->next;
    }
    cout << "\n";
}
int doublyList::size(){
    return count;
}
struct node{
  int data;
  node* next;
};
class DoublyLinkedListClass{
    private:
    node* head;
    
    public:
    DoublyLinkedListClass(){
        head = nullptr;
    }
void insert(int dataToInsert, unsigned int index){
        
        if(index == 0){
            node* backup = head;
            head = new node;
            head->data = dataToInsert;
            head->next = backup;
        }
        
        node* tmp = head;
        for(int i = 0; i < index - 1; i++){
            tmp = tmp->next;
        }
        
        node* backup = tmp->next;
        tmp->next = new node;
        tmp->next->data = dataToInsert;
        tmp->next->next = backup;
        
    }
};