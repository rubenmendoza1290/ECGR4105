#include <iostream>
#include "character.h"
using namespace std;

int main(){
    
    //Initialize characters
    Character player("Bingus", 10, 12, 20, 30);      // Player Character
    Character computer("Big Floppa", 14, 8, 30, 10);  // Computer Character
    cout << "Bingus has encountered a foe! Big Floppa!" << endl;
    
    
    while(player.isAlive() && computer.isAlive()){
        // Combat
        // Who is faster?
        
        if(player.getSpeed() > computer.getSpeed()){
            // Player attacks first
            cout << "Big Floppa's health is now: " ;computer.takeDamage(player.getStrength()); //health = health - (attack's str - def);
            cout << endl;
            
            if(computer.isAlive() == false)
                break;
                
            cout << "Bingus' health is now: " ;player.takeDamage(computer.getStrength());
            cout << endl;
            
            
        } else {
            // Computer attacks first
            if(player.getSpeed() < computer.getSpeed()){
            cout << "Bingus' health is now: " ;player.takeDamage(computer.getStrength()); //health = health - (attack's str - def);
            cout << endl;
            
            if(player.isAlive() == false)
                break;
                
            cout << "Big Floppa's health is now: " ;computer.takeDamage(player.getStrength());
            cout << endl;
        }
        
    }
    }
    
    // Evaluate winner
    if(computer.isAlive() == false){
    cout << "Bingus has won!" << endl; }
    else{
        cout << "Big Floppa has defeated you!" << endl;
    }
    
    //Print conclusion
    
    
    return 0;
}