#include <iostream>
#include <vector>
#include <fstream>
#include <cstring>
#include <string>
#include <ctype.h>
using namespace std;

string a = "abcdefghijklmnopqrstuvwxyz";

string Decrypt(string key, string & cipher)
{
    int freq[26] = {0};
    string KEY = "";
    for(char c : key)
    {
        if (freq[c - 'a'] == 0)
        {
            KEY += c;
            freq[c - 'a']++;
        }
    }
    for(int i = 26; i >= 0; i--)
    {
        if (freq[a[i] - 'a'] == 0) KEY += a[i];
    }
    string plaintext = "";
    for(char c : cipher)
    {
        if(c == ' ')
        {
            plaintext += c;
        }
        else
        {
            int idx = -1;
            for(int i = 0; i < 26; i++)
            {
                if(KEY[i] == c)
                {
                    idx = i;
                    break;
                }
            }
            if(idx != -1) plaintext += a[idx];
        }
    }
    return plaintext;
}

string Encrypt(string key, string & plaintext)
{
    int freq[26] = {0};
    string KEY = "";
    for(char c : key)
    {
        if (freq[c - 'a'] == 0)
        {
            KEY += c;
            freq[c - 'a']++;
        }
    }
    for(int i = 26; i >= 0; i--)
    {
        if(freq[a[i] - 'a'] == 0) KEY += a[i];
    }
    string ciphertext = "";
    for(char c : plaintext)
    {
        if(c == ' ')
        {
            ciphertext += c;
        }
        else
        {
            ciphertext += KEY[c - 'a'];
        }
    }
    return ciphertext;
}

int main(int argc, char ** argv)
{
    bool encrypt;
    bool decrypt;
    string key, inputfile, outputfile;
    for(int i = 1; i < argc; i++)
    {
        if(strcmp(argv[i], "-e") == 0)
        {
            encrypt = true;
            continue;
        }
        if(strcmp(argv[i], "-d") == 0)
        {
            decrypt = true;
            continue;
        }
        if(strcmp(argv[i], "-k") == 0)
        {
            key = argv[i + 1];
            continue;
        }
    }
outputfile = argv[argc - 1];
inputfile = argv[argc - 2];
ifstream intxt(inputfile);
ofstream outxt(outputfile);
    if(encrypt)
    {

        if(outxt.is_open() && intxt.is_open())
        {
            string line;
            while (getline(intxt, line))
            {
                outxt << Encrypt(key, line) << endl;
            }
        }
        else
        {
            cout << "Invalid file\n";
        }
    }
    else
    {
        if(outxt.is_open() && intxt.is_open())
        {
            string line;
            while (getline(intxt, line))
            {
                outxt << Decrypt(key, line) << endl;
            }
        }
        else
        {
            cout << "Invalid file\n";
        }
    }
    intxt.close();
    outxt.close();
    cout << "DONE.\n";
    return 0;
}