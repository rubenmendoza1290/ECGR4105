#include "land.h"
Land* getRandomLand(){
    LandTypes selection = (LandTypes)(rand() % NUM_LANDS);
    
    switch(selection){
        case FOREST:
            return new Forest;
        break;
        case LAKE:
            return new Lake;
        break;
        case DESERT:
            return new Desert;
        break;
        case SWAMP:
            return new Swamp;
        break;
        case FARM:
            return new Farm;
        break;
        case CASTLE:
            return new Castle;
        break;
        case CABIN:
            return new Cabin;
        break;
        case CITY:
            return new City;
        break;
        default:
            return nullptr;
        break;
    }
}
string Forest::getDescription(){
    return "a densely wooded forest.";
}
string Forest::visit(Player& player){
    player.setHunger(player.getHunger() + 1);
    return "You venture into the forest and forage for nuts and berries, restoring your hunger";
}
string Lake::getDescription(){
    return "a sparkling clear lake.";
}
string Lake::visit(Player& player){
    player.setThirst(player.getThirst() + 1);
    return "You drink from the lake, re-hydrating yourself.";
}
string Desert::getDescription(){
    return "a sweaty, hot, sandy desert";
}
string Desert::visit(Player& player){
    player.setThirst(player.getThirst() - 1);
    return "You have a diffucult time through the hot desert with no water.";
}
string Swamp::getDescription(){
    return "a foggy wet swamp";
}
string Swamp::visit(Player& player){
    int chance = rand() % 100;
    return "You attempt to fish and hunt for food";
    
    // Chance to find fish
    if(chance > 50){
        player.setHunger(player.getHunger() + 1);
        return "You manage to catch enough for the day!";
        }
        
    // Chance to be a terrible hunter
    if(chance < 10 && chance > 5){
        player.setHunger(player.getHunger() - 1);
        return "You have a horrible day today and sleep for dinner!";
        }
    // Chance to get mauled by alligator
    if(chance < 5){
        int newHealth = (int)player.getHealth() - 2;
        newHealth = newHealth < 0 ? 0 : newHealth;
        player.setHealth(newHealth);
        return "You get attacked by an alligator!";
        }
}
string Farm::getDescription(){
    return "rolling green fields with the smell of home made stew coming from a farm house in the middle";
}
string Farm::visit(Player& player){
    player.setHunger(player.getHunger() + 1);
    return "You have a nice, good, warm, home-made meal";
}
string Castle::getDescription(){
    return "You spot a Castle straight ahead!";
}
string Castle::visit(Player& player){
    int chance = rand() % 100;
    
    // Chance to find dragon
    if(chance > 50){
        player.setHealth(player.getHealth() - 1);
        return "You get ambushed by a fire-breathing dragon and end up wounded";
        }
        
    // Chance to be a good knight
    if(chance < 50){
        player.setHunger(player.getHunger() + 2);
        return "You manage to slay the dragon and eat him for dinner!!";
        }
}
string Cabin::getDescription(){
    return "A wonderful small cabin in the middle of the woods!";
}
string Cabin::visit(Player& player){
    player.setThirst(player.getThirst() + 2);
    return "You end up finding bottles of water in the cabin.";
}
string City::getDescription(){
    return "A dirty, dangerous city.";
}
string City::visit(Player& player){
    
  int chance = rand() % 100;
    
     if(chance > 60){
        player.setHealth(player.getHealth() - 1);
        return "You get robbed and beat by some thugs";
        }
        
    // Chance to eat good
    if(chance < 60){
        player.setHunger(player.getHunger() + 2);
        return "You manage to find a good resturant to eat in!";
        } 
}