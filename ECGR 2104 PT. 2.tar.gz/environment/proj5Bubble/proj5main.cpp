#include <iostream>
#include <bits/stdc++.h>

using namespace std;

void swap(int *xp, int *yp){
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void bubbleSort(int* a, int size){
    int i, j;
    if (a == nullptr){
        cout << "done!" << endl;
    }
    else{
    for (i = 0; i < size - 1; i++)
    
    for(j = 0; j < size - i - 1; j++)
        if(a[j] > a[j+1])
            swap(&a[j], &a[j+1]);
    }
}

void printArray(int* a, int fsize){
    int i;
    for(i = 0; i < fsize; i++)
        cout << a[i] << " ";
        cout << endl;
}



int main(){
    const int SIZE = 5;
    int a1[] = {3, 4, 8, 2, 1};
    int* p = nullptr;

    bubbleSort(a1, SIZE);
    
    for(int i = 0; i < SIZE; i++){
        cout << a1[i] << endl;
    }

    bubbleSort(nullptr, SIZE);
    
    return 0;
}