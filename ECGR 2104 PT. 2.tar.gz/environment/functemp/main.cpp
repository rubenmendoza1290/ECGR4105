#include <iostream>
#include <sstream>

using namespace std;

int main(){
    
    float num = 24.56;
    string str = "Hello";
    int num2 = 10;
    
    ostringstream oss;
    
    oss << str << " " << num << " " << num2;
    
    string str2 = oss.str();
    
    cout << oss.str() << endl;
    
    return 0;
}

//useful to print out a bunch of data and something string
//if i were to write a function
//alot of the concepts here are purposed so that we can code dynamically and it is modular
//try to have less dependancies it increases modularity,
//if you are to write things into a string use string stream