#include <iostream>

using namespace std;

int multiply(int a, int b) {
    int i = 0;
    int r = 0;
    while(i < b){
        r = r + a;
        i++;
    }
    return r;
}

int main(){
    int j = 5;
    int k = 3;
    int h = multiply(j, k);
    
    cout << h << endl;
    
    return 0;
}