#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>

using namespace std;


string encrypt(string inFile, int key)
{
    string result = "";
 
    // traverse file
    for (int i=0;i<inFile.length();i++)
    {
        // Encrypt Uppercase 
        if (isalpha(inFile[i]) && isupper(inFile[i]))
            result += char(int(inFile[i] + key -65)%26 +65);
 
    // Encrypt Lowercase 
   if (isalpha(inFile[i]) && islower(inFile[i]))
        result += char(int(inFile[i] + key -97)%26 +97);
    }
 
    // Return the resulting string
    return result;
}

string decrypt(string inFile, int key)
{
    string result = "";
 
    // traverse text
    for (int i=0;i<inFile.length();i++)
    {
        // Encrypt Uppercase letters
        if (isalpha(inFile[i]) && isupper(inFile[i]))
            result += char(int(inFile[i]- key -65)%26 +65);
 
    // Encrypt Lowercase letters
   if (isalpha(inFile[i]) && islower(inFile[i]))
        result += char(int(inFile[i]- key -97)%26 +97);
    }
 
    // Return the resulting string
    return result;
}




int main (int argc, char* argv[]){

if (argc != 8){ //explain usage using cout
  cout << "Not the correct way to input" << endl;
return 1;
}

string inFile;
string input;
string output;
ifstream inFS;
ofstream outFile;
int key;
bool tofencrypt;
//parse thru arguments and set variables
for(int i = 1; i < argc; i++)
{

if(strcmp(argv[i], "-e") == 0){
    tofencrypt = true;
}

if(strcmp(argv[i], "-k") == 0){
if(i + 1 < argc){
key = atoi(argv[++i]);
}
}

if(strcmp(argv[i], "-i") == 0)
{
input = argv[++i];
inFS.open(input);
if (!inFS.is_open())
 {
      cout << "Could not open file " << input << "." << endl;
      return 1;
 }
while(!inFS.eof()){
getline(inFS, inFile);
}
}
//encrypt code

if(strcmp(argv[i], "-d") == 0){
    bool tofencrypt = false;
}


if(strcmp(argv[i], "-o") == 0)
{
    if(i + 1 < argc){
output = argv[++i];
}
}

}


if(tofencrypt){
outFile.open(output);

//write on file:
outFile << encrypt(inFile, key) << endl;
//close file:
outFile.close();

}

else{
    outFile.open(output);

//write on file:
outFile << decrypt(inFile, key) << endl;
//close file:
outFile.close();
}

return 0;
}