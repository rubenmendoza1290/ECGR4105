#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include "student.h"

using namespace std;


//constructor is a function that is called whenever class is created
//we can modify them to change something in class.
//not gonna make a student class without making name

//rando 
/*
int nextVal(){
    static int i = 0;
    cout << i++ << endl;
    return i;
}
*/


int main(){
    
    Student s1("Sam Shue");//this is how you utilize that constructor
    s1.addGrade(-1.5);
    s1.addGrade(3.0);
    s1.addGrade(1.0);
    s1.addGrade(2.0);
    
    
    //consturctors provide conveniece and mitigate potential bugs
    Student s2;
    
    cout << s1.getId() << endl;
    cout << s2.getId() << endl;
    
    //cout << Student::getNextStudentId() << endl;
    
    
    
    /*
    Student s2;
    s2.setName("Phil Cole");
    s2.setGpa(4.0);
    
    vector<Student> students;
    students.push_back(s1);
    students.push_back(s2);
    
    for(int i = 0; i < students.size(); i++){
        cout << (students.at(i)).getName() << endl;
        cout << (students.at(i)).getGpa() << endl;
    }
    
    */
    /*
    vector<string> names = {"Samuel Samuelson", "Yousef Yousefson", "Phil Cole"};
    vector<double> gpa = {1.0, 2.0, 4.0};
    
    //string names[LENGTH];
    //double gpa[LENGTH];
    
    names.push_back("Sam Samson");
    gpa.push_back(1.0);
    
    names.push_back("Bob Bobson");
    gpa.push_back(3.0);
    
    names.push_back("Jack Jackson");
    gpa.push_back(3.0);
    
    names.pop_back();
    gpa.pop_back();
    
    for(int i = 0; i < names.size(); i++){
        cout << names.at(i) << endl;
        cout << gpa.at(i) << endl;
    }
    */
    
    return 0;
}