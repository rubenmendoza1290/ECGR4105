#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <vector>
using namespace std;
class Student {
    public:
    Student();
    //when you specify a constructor like this, you have to use it, you've overwritten the default
    //thats the consturctor, called whenever build class to change insturctor? sumn like that
    //weird looking function with exact same name as class:
    Student(string n);
    //function named after class and no return type associated with it is how you can tell
    Student(string n, unsigned int i);
    
    //void setGpa(double num);
    void setName(string n);
    void addGrade(double g);
    void setId(unsigned int i);
    double getGpa() const;
    string getName() const;
    int getId() const;
   // static unsigned int getNextStudentId(); //static allows me to use function without making an instance of the student class
    
    private:
    string name;
    unsigned int id;
    //double gpa;
    vector<double> grades; //allows us to store a list of grades so when we call it it can calculate a gpa
    unsigned int getNextStudentId();
    
    static unsigned int nextId;
};
#endif