#include "student.h"
/*
//define funciton inside class:
    void Student::setGpa(double num){ //scope resolution operator
        if(num < 0) //control what values can be set in variable, prevents weird numbers to be assigned to variables
            num = 0.0; //sidenote: with any kind of if statement, its optional to add { if only have one line below
        if(num > 4)
            num = 4.0;
        gpa = num;
        
    }
    */
    
    void Student::addGrade(double g){
        if(g)
    }
    
    void Student::setName(string n){
        name = n;
    }
    
    double Student::getGpa() const {
        double sum = 0.0;
        for(int i = 0; i < grades.size(); i++){
            sum += grades.at(i);
        }
        double gpa = sum / (double)grades.size();
        
        return gpa;
    }
    
    string Student::getName() const {
        return name;
    }//make it so that no one can change name/gpa
    