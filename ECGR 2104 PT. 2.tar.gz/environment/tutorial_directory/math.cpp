#include "math.h"

using namespace std;

double divide(int x, int y){
    double r = x / y;
    
    return r;
}

double divide (double x, double y){
    double r = x / y;
    return r;
}

double multiply(int x, int y){
    return x*y;
}

void printHello(){
    cout << "Hello" << endl;
}