#include <iostream> //iostream pulls in string library
#include <string> //can do it manually as well, string is a class?
#include <vector>
#include <stdlib.h>
#include <math.h>

using namespace std;

//anything with a . "names.push_back()" is an object
//lets create our first object here:
class Student { //class definition, it doesn't "exist" its like a blueprint
public: //so we add this to make it public
  string name; //whenever we declare a variable inside a class, its private, only the class can access it, prevents anyone from messing with values
  double gpa;
private:
};

//#define SOME_NUMBER 4 //typing in all caps is standard for something that cannot be changed

int main(){
    
    Student s1;
    s1.name = "Sam Shue";
    s1.gpa = 1.5;
    
    Student s2;
    s2.name = "Phil cole";
    s2.gpa = 4.0;
    
    
    vector<Student> students;
    students.push_back(s1);
    students.push_back(s2);
    
    for(int i = 0; i < students.size(); i++){
        cout << students.at(i).name << endl; //accessing student directory
        cout << students.at(i).gpa << endl;
    }
    
    /*
    //declare a vector: have to declare what the vector is holding
    vector<string> names = {"Samuel Samuelson", "Yousef Yousefson", "Phil Cole"}; //creating a VECTOR that holds STRINGS
    //can preallocate names using curly braces, what it will do is inline create an array 
    vector<double> gpa = {1.0, 2.0, 4.0};
    vecotr<string> major = {"Biology", "CpE", "EE"};
    
    //lists:
    //use arrays
    //example string: create student database, create an array of names:
    //string names[LENGTH]; //[] how many items/elements
    
    //give another associated value: GPA
    //double gpa[LENGTH];
    
    //creates space in memory for 3 strings created side by side to access individual elements
    names.push_back("Sam Shue"); //everything in computer eng. starts with 0
    gpa.push_back(1.0);

    //strings/arrays are very dumb, no built in features, pile of variables
    //what if want to in the future add students? VECTORS
    //Pull in vector class on top^^
    names.push_back("Bob Bobson"); //creates extra space to vector
    gpa.push_back(3.0);
    
    names.push_back("Jack Jackson");
    gpa.push_back(3.0);
    
    
    //removes whatever last element in array of vector, ejects whatever last one was
    //lets say sam academic probation, 
    names.pop_back();
    gpa.pop_back();
    
    //vecotrs are smart, they're "aware" of how large they are
    for(int i = 0; i < names.size(); i++){ //don't want to go outside number of string in i < n
        cout << names.at(i) << endl; //.at(i) returns some reference, does same thing as [i] which is direct access to where it is
        //whenever using vectors, safer to use .at(i)
        cout << gpa.at(i) << endl;
    }
    
    //arrays are way faster than vectors
    //vectors are smarter though
    */
    return 0;
}