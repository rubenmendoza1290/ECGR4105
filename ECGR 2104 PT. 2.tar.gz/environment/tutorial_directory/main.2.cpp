//Wed. Jan 26

#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include "student.h"

using namespace std;

int main(){
    Student s1;
    s1.setName("Sam Shue");
    s1.addGrade(1.5);
    s1.addGrade(3.0);
    s1.addGrade(1.0);
    s1.addGrade()
    
    cout << s1.getGpa() << endl;
    /*
    Student s2;
    s2.setName("Phil Cole");
    s2.setGpa(4.0);
    
    vector<Student> students;
    students.push_back(s1);
    students.push_back(s2);
    
    for(int i = 0; i < students.size(); i++){
        cout << (students.at(i)).getName << endl;
        cout << (students.at(i)).getGpa << endl;
    }
      */
    return 0;
}