#ifndef STUDENT_H
#define STUDENT_H

#include <string>
#include <vector>

using namespace std;


class Student {
    public:
    //void setGpa(double num);
    void setName(string n);
    void addGrade(double g);[]
    double getGpa() const;
    string getName() const;
    
    private:
    string name;
    double gpa;
    vector<double> grades;
};

#endif