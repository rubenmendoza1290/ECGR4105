#ifndef MATH_H //preproccessor n command
//if MATH_H not defined, go ahead with code below, if not, go to #endif
#define MATH_H

#include <iostream>

//^include gaurds

#define PI 3.14

double divide(int x, int y);
double divide(double x, double y);
double multiply(int x, int y);
void printHello(void);

#endif