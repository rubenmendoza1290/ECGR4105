#include <iostream>
#include <exception>

using namespace std;

class My_Exception : public exception{
    public:
    const char* what() const noexcept{
        return "Bad things happened!";
    }
};



int main(){
  
  try {
      throw My_Exception();
  }  catch (exception e) {
      cout << e.what() << endl;
  }
    
      return 0;
}