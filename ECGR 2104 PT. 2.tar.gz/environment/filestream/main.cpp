//file streams allow user to read and write data to a file
//ifstream - read files (input file stream)
//ofstream - writing to files (output file stream)
//fstream - used for both reading and writing
//write a program that:

#include <iostream>
#include <fstream>

using namespace std;

int main(){
    ofstream outFile;
    //create file:
    outFile.open("hello.txt");
    //write on file:
    outFile << "Hello World!" << endl;
    outFile << "Hello World!" << endl;
    outFile << "Hello World!" << endl;
    outFile << "Hello  World!" << endl;
    
    //close file:
    outFile.close();
    
   /* ifstream inFile;
    
    inFile.open("hello.txt");
    
    string contents;
    string temp;
    while(!inFile.eof()){
        getline(inFile, temp);
        contents += temp;
        contents += '\n';
    }
    
    inFile.close();
    
    cout << contents << endl;
    */
    
    return 0;
}