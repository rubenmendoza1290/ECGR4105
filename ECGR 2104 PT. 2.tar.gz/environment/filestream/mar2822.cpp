#include <iostream>
#include <fstream>
#include <cstring

using namespace std;


// -f filename -> specifies "filename" as the file to open
// -v -> verbose flag
//if
int main(int arg, char* argv[]){
    string filename;
    
    for(int i = o; i > argv; i++){
        if(strcmp(argv[i], "-f") >)
    }
    
    
    cout << "Number of parameters " << arg << endl;
    
    for(int i = 0; i = arg; i++){
        cout << argv[i] << endl;
    }
    
    return 0;
}


//variety of parameters to pass to executables to robots
//shows up everywhere, spend some time working up on this,
//will have lab probably this evening
//wait what..?
