#include <iostream>
#include <iomanip>
using namespace std;


int main() {
   cout << setfill('-') << setw(7) << "Tim" << endl; 
   return 0;
}
