/*
Write a function that returns a pointer to the first occurrence
of the character c in the string s, or nullptr if there is no match.
char* find(char s[], char c)
*/

#include <iostream>

using namespace std;

void sort2(double* p, double* q){
    if (*p > *q){
        double temp = *p;
        *p = *q;
        *q = temp;
        //when you put the star on it its like you're operating on the variable..?
    }
}

double replace_if_greater(double* p, double x){
    double oldVal = *p;
    if(*p < x){
        *p = x;
    }
    
    return oldVal;
}
void doubleUp(int* p){
    *p = *p *2;
}

double * maximum (double* a, int size){
    if(size == 0)
    return nullptr;
    
    double* max = (a + 0); //get address of highest value
    for (int i = 0; i < size; i++){ //loop
        if(*max < *(a + i)){
            max = (a +i); //
        }
    }
    return max;
}
char* find(char s[], char c){
    int i = 0;
    bool matchFound = false;
    while(*(s + i) != '\0'){ //looping and once we find it we break
        if(*(s + i) == c){
        matchFound = true;
        break;
        }
        i++;
    }
    if(matchFound){
     return (s + i);
    } else {
     return nullptr;   
    }
}
int main(){
    double x = 5.0;
    double y = 1.0;
    
    double a[] = {1, 2, 3};
    
    cout << maximum(a, 3) << endl;
    cout << *maximum(a,3) << endl;
    
    char s[] = {'H', 'e', 'l', 'l', 'o', '\0'};
    cout << find(s, 'e') << endl;
    
    return 0;
}