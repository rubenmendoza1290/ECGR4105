#include <iostream>

using namespace std;

/* EX1
Write a function ,void sort2(double* p, double* q),
that receives two pointers and sorts the values to
which they point. If you callsort2(&x, &y) then x <= y after the call*/
void sort2(double* p, double* q){
    if (*p > *q){
        double temp = *p;
        *p = *q;
        *q = temp;
        //when you put the star on it its like you're operating on the variable..?
    }
}

/* EX2
Write a function ,double replace_if_greater(double* p, double x), that
replaces the value to which p points with x is greater. Return the
old value to which p pointed.
*/
double replace_if_greater(double* p, double x){
    double oldVal = *p;
    if(*p < x){
        *p = x;
    }
    
    return oldVal;
}
void doubleUp(int* p){
    *p = *p *2;
}
/*void doubleUp(int& x){
    x = x * 2;
}*/
//both do same thing^^
//pastby reference is not in C language
//back then if you wanted to modify youd have to pass the address because pastby reference wasnt there
//passby reference is a short cut for passing a pointer
//there's alot of shortcuts that these languages offer us but we can do with pointers instead
int main(){
    double x = 5.0;
    double y = 1.0;
    
    int a[] = {1, 2, 3};
    
    /*sort2(&x, &y); //dereference x
    double o = replace_if_greater(&x, 10.0);
    
    cout << x << ", " << o << endl;*/
    
    cout << a[2] << endl;
    cout << *(a+ 2) << endl;
    
    
    
    return 0;
}