#include <iostream>

using namespace std;

int main(){
    int x = 5;
    int y = 10;
    long int* px = (long int*)&x;
    long int* py = (long int*)&y;
    
    
    cout << px << endl;
    cout << py << endl;
    
    
    
    
    cout << *px << endl;
    cout << *py << endl;
    
    return 0;
}