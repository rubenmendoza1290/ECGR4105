/*
Write a function that returns a pointer to the maximum value of an array
of floating-point data: double* maximum(double* a, int size).
If size is 0, return nullptr.
*/

#include <iostream>

using namespace std;

void sort2(double* p, double* q){
    if (*p > *q){
        double temp = *p;
        *p = *q;
        *q = temp;
        //when you put the star on it its like you're operating on the variable..?
    }
}

double replace_if_greater(double* p, double x){
    double oldVal = *p;
    if(*p < x){
        *p = x;
    }
    
    return oldVal;
}
void doubleUp(int* p){
    *p = *p *2;
}

double * maximum (double* a, int size){
    if(size == 0)
    return nullptr;
    
    double* max = (a + 0); //get address of highest value
    for (int i = 0; i < size; i++){ //loop
        if(*max < *(a + i)){
            max = (a +i); //
        }
    }
    return max;
}

int main(){
    double x = 5.0;
    double y = 1.0;
    
    int a[] = {1, 2, 3};
    
    cout << maximum[a, 3] << endl;
    cout << *maximum(a,3) << endl;
    
    
    
    return 0;
}