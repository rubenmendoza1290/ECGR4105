#include <iostream>
using namespace std;
struct Point2D{
    Point2D(double x, double y){
        this->x = x;
        this->y = y;
    }
    
    Point2D operator+(Point2D p){
        Point2D sum(0.0, 0.0);
        sum.x = x + p.x;
        sum.y = y + p.y;
        return sum;
    }
    
    Point2D operator-(Point2D p){
        Point2D sum(0.0, 0.0);
        sum.x = x - p.x;
        sum.y = y - p.y;
        return sum;
    }
    
    bool operator==(Point2D p){
        return (x == p.x) && (y == p.y);
    }
    
    void print(){
        cout << x << ", " << y << endl;
    }
    
    double x;
    double y;
};
class Square{
    public:
    Square(double length) : p0(0.0, 0.0), p1(length, 0.0), p2(0.0, length), 
p3(length,length) {
    }
    
    void print(){
        p0.print();
        p1.print();
        p2.print();
        p3.print();
    }
    
    Point2D p0, p1, p2, p3;
};
int main(){
    
    Point2D p1(1.0, 2.0);
    Point2D p2(3.0, 5.0);
    
    Point2D sum(0.0, 0.0);
    
    //sum = p1.add(p2);
    sum = p1 + p2;
    
    //sum.print();
    
    Square s(5.0);
    
    s.print();
    
    return 0;
}