#include <iostream>
using namespace std;
class food{
    public:
    food(double x, double y, double z, double a){
        this->x = x;
        this->y = y;
        this->z = z;
        this->a = a;
    }
    
    food operator+(food f){
        food sum(0.0, 0.0, 0.0, 0.0);
        sum.x = x + f.x;
        sum.y = y + f.y;
        sum.z = z + f.z;
        sum.a = a + f.a;
        return sum;
    }
    
    void print(){
        cout << x << ", " << y << ", " << z << ", " << a << endl;
    }
    
    double x;
    double y;
    double z;
    double a;
    
};
int main(){
    
    food f1(1.0, 2.0, 4.0, 3.0);
    food f2(3.0, 5.0, 2.0, 3.0);
    
    food sum(0.0, 0.0, 0.0, 0.0);
    
    //sum = p1.add(p2);
    sum = f1 + f2;
    
    sum.print();
    
    
    return 0;
}