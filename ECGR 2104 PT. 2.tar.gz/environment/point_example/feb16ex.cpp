#include <iostream>

using namespace std;

int main(){
    int* p = new int[3];
    p[0] = 1;
    p[1] = 2;
    p[2] = 3;
    
    for(int i = 0; i < 3; i++)
        cout << p[i] << endl;
    
    /*
    cout << &p << endl; //prints 0x7ffcfde34298
    cout << p << endl;  //prints 0x13d4e70
    cout << *p << endl; //prints 10 or int value
    */
    
    delete[] p;
    
    int* p2 = new int[3];
    cout << p << endl;
    cout << p2 << endl;
    
    return 0;
}