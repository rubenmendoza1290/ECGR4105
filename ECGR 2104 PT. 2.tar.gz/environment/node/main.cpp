#include <iostream>

using namespace std;

//iterate through the list to find the end
node* temp = head;
while(temp->next != nullptr){
    temp = temp->next;
}
//add new mode at end of chain and populate data
temp->next = new node;
temp->next->data = data;
}

void kill(node* head, int indexToRemove){
    node* currentNode = head;
    int currentIndex = 0;
    
    while(true){
        //Is current index 1 behind the requested index?
    if(currentIndex == (indexToRemove - 1)){
        break;
    }
    
    //crawl to next element
    currentIndex++;
    currentNode = currentNode->next;
}
//Backup next, next node address
node* temp = currentNode->next->next;
//Delete node to be removed
delete currentNode->next;
//Stitch pointers back together
currentNode->next = temp;




}

int size(node* head){
    int numElements = 0
    
    if(head == nullptr){
        return numElements;
    }
    while(true){
        
    }
}

int main(){
    node* head = nullptr;
    
    push(head, 1);
    push(head, 2);
    push(head, 3);
    
    kill(head, 2);
    
    cout << size(head) << endl;
    
    for(int i = 0; i < size(head); i++){
        cout << at(head, i) << endl;
    }
    return 0;
}