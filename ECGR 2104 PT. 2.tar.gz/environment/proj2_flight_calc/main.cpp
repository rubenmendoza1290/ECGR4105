#include <iostream>
#include <vector>
#include <stdlib.h>
#include <math.h>

using namespace std;

class City {
    public:
    string name;
    double latitude;
    double longitude;
};

static double hs(double lat1, double lon1,
                        double lat2, double lon2)
    {
        double dLon = (lon2 - lon1) *
                      M_PI / 180.0;
        double dLat = (lat2 - lat1) *
                      M_PI / 180.0;
        lat1 = (lat1) * M_PI / 180.0;
        lat2 = (lat2) * M_PI / 180.0;
        double a = pow(sin(dLat / 2), 2) +
                   pow(sin(dLon / 2), 2) *
                   cos(lat1) * cos(lat2);
        double radius = 3958.8;
        double c = 2 * asin(sqrt(a));
        return radius * c;
    }


int main(){
    
    int departure;
    string depart;
    int destination;
    string destin;
    int latitude1;
    double lat1;
    double lon1;
    double lat2;
    double lon2;
    double time;
    
    City c1;
    c1.name = "1. Miami Beach, FL, USA ";
    c1.latitude = 25.793449;
    c1.longitude = -80.139198;
    
    City c2;
    c2.name = "2. Fargo, ND, USA ";
    c2.latitude = 46.877186;
    c2.longitude = -96.789803;
    
    City c3;
    c3.name = "3. Idaho City, ID, USA ";
    c3.latitude = 43.828850;
    c3.longitude = -115.837860;
    
    City c4;
    c4.name = "4. Shelton, CT, USA ";
    c4.latitude = 41.306583;
    c4.longitude = -73.143768;
    
    City c5;
    c5.name = "5. Bartow, FL, USA ";
    c5.latitude = 27.891005;
    c5.longitude = -81.847359;
    
    City c6;
    c6.name = "6. Atlantic City, NJ, USA ";
    c6.latitude = 39.370121;
    c6.longitude = -74.438942;
    
    City c7;
    c7.name = "7. Jacksonville, IL, USA ";
    c7.latitude = 39.741550;
    c7.longitude = -90.256218;
    
    City c8;
    c8.name = "8. Panama City, FL, USA ";
    c8.latitude = 30.193626;
    c8.longitude = -85.683029;
    
    City c9;
    c9.name = "9. Central City, CO, USA ";
    c9.latitude = 39.803318;
    c9.longitude = -105.516830;
    
    City c10;
    c10.name = "10. Tuskegee, AL, USA ";
    c10.latitude = 32.429066;
    c10.longitude = -85.715233;
    
    vector<City> cities;
    cities.push_back(c1);
    cities.push_back(c2);
    cities.push_back(c3);
    cities.push_back(c4);
    cities.push_back(c5);
    cities.push_back(c6);
    cities.push_back(c7);
    cities.push_back(c8);
    cities.push_back(c9);
    cities.push_back(c10);
    
    cout << "Choose a Departure location: \n" << endl;
    
    for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl; //accessing student directory
    }
    
    cin >> departure;
    
    if(departure == 1){
        depart = c1.name;
        double lat1 = c1.latitude;
        double lon1 = c1.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 1){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    else if(departure == 2){
        depart = c2.name;
        double lat1 = c2.latitude;
        double lon1 = c2.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 2){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    else if(departure == 3){
        depart = c3.name;
        double lat1 = c3.latitude;
        double lon1 = c3.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 3){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    
    else if(departure == 4){
        depart = c4.name;
        double lat1 = c4.latitude;
        double lon1 = c4.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 4){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else{
            cout << "please choose a number from the list \n" << endl;
        }
    }
    
    
    
    
    
    
    else if(departure == 5){
        depart = c5.name;
        double lat1 = c5.latitude;
        double lon1 = c5.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 5){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    
    
    
    
    else if(departure == 6){
        depart = c6.name;
        double lat1 = c6.latitude;
        double lon1 = c6.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 6){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    
    
    
    else if(departure == 7){
        depart = c7.name;
        double lat1 = c7.latitude;
        double lon1 = c7.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 7){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    
    
    
    
    else if(departure == 8){
        depart = c8.name;
        double lat1 = c8.latitude;
        double lon1 = c8.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 8){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    
    
    
    else if(departure == 9){
        depart = c9.name;
        double lat1 = c9.latitude;
        double lon1 = c9.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
        while (destination == 9){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 10){
            destin = c10.name;
            double lat2 = c10.latitude;
            double lon2 = c10.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    
    
    
    
    
    
    else if(departure == 10){
        depart = c10.name;
        double lat1 = c10.latitude;
        double lon1 = c10.longitude;
        cout << "you chose: " << depart << "\n" << endl;
        cout << "Choose a Desitnation: \n" << endl;
        
        for(int i = 0; i < cities.size(); i++){
        cout << cities.at(i).name << cities.at(i).latitude << cities.at(i).longitude << endl;//accessing student directory
        }
        cin >> destination;
       while (destination == 10){
            cout << "please choose a different destination! \n" << endl;
            cin >> destination;
        }
        if (destination == 1){
            destin = c1.name;
            double lat2 = c1.latitude;
            double lon2 = c1.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 2){
            destin = c2.name;
            double lat2 = c2.latitude;
            double lon2 = c2.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 3){
            destin = c3.name;
            double lat2 = c3.latitude;
            double lon2 = c3.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 4){
            destin = c4.name;
            double lat2 = c4.latitude;
            double lon2 = c4.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 5){
            destin = c5.name;
            double lat2 = c5.latitude;
            double lon2 = c5.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 6){
            destin = c6.name;
            double lat2 = c6.latitude;
            double lon2 = c6.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 7){
            destin = c7.name;
            double lat2 = c7.latitude;
            double lon2 = c7.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if(destination == 8){
            destin = c8.name;
            double lat2 = c8.latitude;
            double lon2 = c8.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
        else if (destination == 9){
            destin = c9.name;
            double lat2 = c9.latitude;
            double lon2 = c9.longitude;
            cout << "you chose: " << destin << "\n" << endl;
    
            cout << hs(lat1, lon1,
                      lat2, lon2) << " miles. \n";
            double time = (hs(lat1, lon1,
                      lat2, lon2)) / 575;
            cout << "you'll get there in " << time << " hrs." << endl;
        }
    }
    /*
    cout << hs(lat1, lon1,
                      lat2, lon2) << " K.M.";
    */
    /*
    int num1, num2;
    cout << "Enter two numbers to calculate its sum: " << endl;
    cin >> num1 >> num2;
    int num3;
    num3 = num1 + num2;
    cout << num1 << " + " << num2 << " = " << num3 << endl;
    */
    
    return 0;
}