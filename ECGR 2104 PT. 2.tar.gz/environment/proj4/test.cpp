#include<iostream>

using namespace std;
#define MAX_SIZE 20
//enum for all nutrition
enum {
   ENERGY,
   TOTAL_FAT,
   TOTAL_SUGARS,
   PROTEIN,
   SODIUM
};
//Idel valies for all nutrition for an average adult in sequence to energy, fat, sugar, protein, sodium
double averageNutrition[]={2,70,30,50,2.300};
//class Food
class Food
{
   private:
       string name;
       double nutrition[5];//to hold the value of nutrition in sequence to energy, fat, sugar, protein, sodium
   public:
       Food()//default constructor
       {
           nutrition[ENERGY]=nutrition[TOTAL_FAT]=nutrition[TOTAL_SUGARS]=nutrition[PROTEIN]=nutrition[SODIUM]=0;
           name="";
       }
       //perimetrised constructor
       Food(string name_,double energy,double fat,double sugar,double protin,double sodium)
       {
           nutrition[ENERGY]=energy;
           nutrition[TOTAL_FAT]=fat;
           nutrition[TOTAL_SUGARS]=sugar;
           nutrition[PROTEIN]=protin;
           nutrition[SODIUM]=sodium;
           name=name_;
       }
       //setter...
       void setName(string name_)
       {
           name=name_;
       }
       void setEnergy(double energy)
       {
           nutrition[ENERGY]=energy;
       }
       void setFat(double fat)
       {
           nutrition[TOTAL_FAT]=fat;
       }
       void setSugar(double sugar)
       {
           nutrition[TOTAL_SUGARS]=sugar;
       }
       void setProtein(double protein)
       {
           nutrition[PROTEIN]=protein;
       }
       void setSodium(double sodium)
       {
           nutrition[SODIUM]=sodium;
       }
       //getter...
       string getName()
       {
           return name;
       }
       double getEnergy()
       {
           return nutrition[ENERGY];
       }
       double getFat()
       {
           return nutrition[TOTAL_FAT];
       }
       double getSugar()
       {
           return nutrition[TOTAL_SUGARS];
       }
       double getProtein()
       {
           return nutrition[PROTEIN];
       }
       double getSodium()
       {
           return nutrition[SODIUM];
       }
       //overload + operator
       Food operator+(Food& B)
       {
           Food temp;
           temp.nutrition[ENERGY]=nutrition[ENERGY]+B.getEnergy();
           temp.nutrition[TOTAL_FAT]=nutrition[TOTAL_FAT]+B.getFat();
           temp.nutrition[TOTAL_SUGARS]=nutrition[TOTAL_SUGARS]+B.getSugar();
           temp.nutrition[PROTEIN]=nutrition[PROTEIN]+B.getProtein();
           temp.nutrition[SODIUM]=nutrition[SODIUM]+B.getSodium();
           return temp;
       }
};
//function to display nutritional values of selected items.
void dispaly(Food obj)
{
   cout<<"\n\nTotal Intake\n";
  
   cout<<"Energy: "<<obj.getEnergy()<<endl;
   cout<<"Total Fat: "<<obj.getFat()<<endl;
   cout<<"Total Suagr: "<<obj.getSugar()<<endl;
   cout<<"Protein: "<<obj.getProtein()<<endl;
   cout<<"Sodium: "<<obj.getSodium()<<endl;
  
}
//function to add 10 food items in list
int AddItems(Food list[])
{
   Food f1("Apple",1,20,20,1,1);
   Food f2("French Fries",2,30,30,2,2);
   Food f3("Burger",3,40,40,3,3);
   Food f4("Instant Romen",4,50,50,4,4);
   Food f5("Protein Bar",5,60,60,5,5);
   Food f6("Banana",6,70,70,6,6);
   Food f7("Puddings",7,80,80,7,7);
   Food f8("Rice Cakes",8,90,90,8,8);
   Food f9("Cakes",9,100,100,9,9);
   Food f10("Chocolate",10,110,110,10,10);
   list[0]=f1;
   list[1]=f2;
   list[2]=f3;
   list[3]=f4;
   list[4]=f5;
   list[5]=f6;
   list[6]=f7;
   list[7]=f8;
   list[8]=f9;
   list[9]=f10;
  
   return 10;
  
}
//function to check if the nutritional value of selected items exceeds the ideal value
void checkExcesConsumption(Food obj)
{
   if(obj.getEnergy()>averageNutrition[ENERGY])
   {
       cout<<"\nEnergy amount exceeded"<<endl;
   }
   if(obj.getFat()>averageNutrition[TOTAL_FAT])
   {
       cout<<"\nFat amount exceeded"<<endl;
   }
   if(obj.getSugar()>averageNutrition[TOTAL_SUGARS])
   {
       cout<<"\nSugar amount exceeded"<<endl;
   }
   if(obj.getProtein()>averageNutrition[PROTEIN])
   {
       cout<<"\nProtein amount exceeded"<<endl;
   }
   if(obj.getSodium()>averageNutrition[SODIUM])
   {
       cout<<"\nSodium amount exceeded"<<endl;
   }
}

//function to add new item
int addItem(Food list[],int size)
{
   string name;
   double energy,fat,sugar,protein,sodium;
   if(size<MAX_SIZE-1)
   {
       cout<<"\nEnter the name of food";
       cin>>name;
       list[size].setName(name);
       cout<<"\nEnter Energy: ";
       cin>>energy;
       list[size].setEnergy(energy);
       cout<<"\nEnter Fat: ";
       cin>>fat;
       list[size].setFat(fat);
       cout<<"\nnEnter Sugar: ";
       cin>>sugar;
       list[size].setSugar(sugar);
       cout<<"\nnEnter Protein: ";
       cin>>protein;
       list[size].setProtein(protein);
       cout<<"\nnEnter Sodium: ";
       cin>>sodium;
       list[size].setSodium(sodium);
       size++;
   }
   else
   {
       cout<<"\nList is full...!!!";
   }
   return size;
}

//main function
int main()
{
   Food list[MAX_SIZE];//list to hold object of class Food for all added food items
   int size;//size of how munc items are in list
   size=AddItems(list);//call to add 10 food items
   int ch=-1;//a variable to hold user choice (selected item from menu)
   Food selected;//object to hold all selected items
   int selectedItemCount=0;//to count number of selected items
   while(ch!=size+2)//loop the menu till user selected finished option
   {
       for(int i=0;i<size;i++)//print name of all food items already in list
       {
           cout<<"\n"<<i+1<<": "<<list[i].getName();
       }
       cout<<"\n"<<size+1<<": Add new food.";//give user, an aditional option to add new food item by user
       cout<<"\n"<<size+2<<": Finished";//finish option at the end
       cout<<"\n$>> ";//take users choice
       cin>>ch;
       if(ch==size+1)//if user select add new food item choice
       {
           size=addItem(list,size);
       }
       else if(ch<size&&ch>0)//if user select a food item already added
       {
           selected=selected+list[ch-1];//add the nutritional value of item selected with already selected items
           selectedItemCount++;//increment the selected item counter value by 1
       }
       else if(ch<1||ch>size+2)//if user enter an invalid option
       {
           cout<<"\n!!!...Invalid choice...!!!\n";
       }
   }
   if(selectedItemCount>0)//check if user select any food item or not.
   {
       dispaly(selected);//display combine nutritional value of all selected food items
       cout<<endl;
       checkExcesConsumption(selected);//display if any nutritional value exceeded from the ideal value for and average adult
   }
   return 0;
}