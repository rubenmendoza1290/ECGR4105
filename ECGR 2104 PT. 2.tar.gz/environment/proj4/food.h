#ifndef FOODITEM_H
#define maxsize 100
#include <string>
#include <vector>

using namespace std;


enum {Calories, Fat, Sugar, Protein, Sodium};

double nutritionalGoal[] = {2000, 70, 30, 50, 2300};


class fooditem {
    private:
        string foodname;
        double NutritionValues[5];
    public:
        fooditem(){
            NutritionValues[Calories] = NutritionValues[Fat] = NutritionValues [Sugar] = NutritionValues[Protein] = NutritionValues[Sodium] = 0;
            foodname = "unknown";
        }
        fooditem(string name, double cal, double fat, double sugar, double protein, double sodium){
            NutritionValues[Calories] = cal;
            NutritionValues[Fat] = fat;
            NutritionValues[Sugar] = sugar;
            NutritionValues[Protein] = protein;
            NutritionValues[Sodium] = sodium;
            foodname = name;
        }
    //mutators:
        void setName(string name){
            foodname = name;
        }
        void setCalories(double cal){
            NutritionValues[Calories] = cal;
        }
        void setFat(double fat){
            NutritionValues[Fat] = fat;
        }
        void setSugar(double sugar){
            NutritionValues[Sugar] = sugar;
        }
        void setProtein(double protein){
            NutritionValues[Protein] = protein;
        }
        void setSodium(double sodium){
            NutritionValues[Sodium] = sodium;
        }
        //accessors
        string getName(){
            return foodname;
        }
        double getCalories(){
            return NutritionValues[Calories];
        }
        double getFat(){
            return NutritionValues[Fat];
        }
        double getSugar(){
            return NutritionValues[Sugar];
        }
        double getProtein(){
            return NutritionValues[Protein];
        }
        double getSodium(){
            return NutritionValues[Sodium];
        }
        fooditem operator+(fooditem& New){
            fooditem temp;
            temp.NutritionValues[Calories] = NutritionValues[Calories] + New.getCalories();
            temp.NutritionValues[Fat] = NutritionValues[Fat] + New.getFat();
            temp.NutritionValues[Sugar] = NutritionValues[Sugar] + New.getSugar();
            temp.NutritionValues[Protein] = NutritionValues[Protein] + New.getProtein();
            temp.NutritionValues[Sodium] = NutritionValues[Sodium] + New.getSodium();
            return temp;
        }
};
#endif