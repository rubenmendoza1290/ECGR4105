#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include "food.h"

using namespace std;

int fooditems(fooditem list[]){
   fooditem f1("Apple",52,0.2,10.4,0.3,2);
   fooditem f2("French Fries",222,10,0.2,2.4,149);
   fooditem f3("Burger",540,10,0.2,2.4,149);
   fooditem f4("Instant Ramen",188,7,2,5,891);
   fooditem f5("Protein Bar",190,6,23,21,190);
   fooditem f6("Barbacoa",206,7.2,0.3,33,71);
   fooditem f7("Pepperoni Pizza",313,13,3.6,13,760);
   fooditem f8("Buffalo Wings",88,6.5,0.1,4.5,105);
   fooditem f9("Diet Coke",0,0,0,0,40);
   fooditem f10("Mtn Dew Baja Blast",170,0,44,0,55);
   list[0] = f1;
   list[1] = f2;
   list[2] = f3;
   list[3] = f4;
   list[4] = f5;
   list[5] = f6;
   list[6] = f7;
   list[7] = f8;
   list[8] = f9;
   list[9] = f10;
   
   return 10;
}

int addfooditem(fooditem list[], int size){
    string foodname;
    double calories, fat, sugar, protein, sodium;
    cout << "\nEnter a custom food name:";
    cin >> foodname;
    list[size].setName(foodname);
    cout << "\nCalories: ";
    cin >> calories;
    list[size].setCalories(calories);
    cout << "\nFat: ";
    cin >> fat;
    list[size].setFat(fat);
    cout << "\nSugar: ";
    cin >> sugar;
    list[size].setSugar(sugar);
    cout << "\nProtein: ";
    cin >> protein;
    list[size].setProtein(protein);
    cout << "\nSodium: ";
    cin >> sodium;
    list[size].setSodium(sodium);
    size++;
    return size;
}

void Results(fooditem obj){
   cout << "\n Total Nutritional Values:\n\n" << "Calories: " << obj.getCalories() << endl;
   if(obj.getCalories() > nutritionalGoal[Calories]){
       cout << "Caloric intake exceeded" << endl;
   }
   else{
       cout << "Caloric intake NOT exceeded" << endl;
   };
   cout << "\nTotal Fat: "<< obj.getFat() << endl;
   if(obj.getFat() > nutritionalGoal[Fat]){
       cout << "Fat intake exceeded" << endl;
   }
   else{
       cout << "Fat intake NOT exceeded" << endl;
   };
   cout << "\nTotal Suagr: " << obj.getSugar() << endl;
   if(obj.getSugar() > nutritionalGoal[Sugar]){
       cout << "Sugar intake exceeded" << endl;
   }
   else{
       cout << "Sugar intake NOT exceeded" << endl;
   };
   cout << "\nProtein: "<< obj.getProtein() << endl;
   if(obj.getProtein() > nutritionalGoal[Protein]){
       cout << "Protein intake exceeded" << endl;
   }
   else{
       cout << "Protein intake NOT exceeded" << endl;
   };
   cout << "\nSodium: " << obj.getSodium() << endl;
   if(obj.getSodium() > nutritionalGoal[Sodium]){
       cout << "Sodium intake exceeded"<<endl;
   }
   else{
       cout << "Sodium intake NOT exceeded" << endl;
   };
  
}

int main() {
    fooditem list[maxsize];
    int foodlist;
    foodlist = fooditems(list);
    int userChoice = -1;
    fooditem choices;
    int NumChoices = 0;
    while(userChoice != foodlist + 2){
        cout << "Pick any food item from the list below or feel free to enter a custom food item: " << endl;
        for(int i = 0; i<foodlist; i++){
            cout << "\n" << i + 1 << ": " << list[i].getName();
        }
        cout << "\n" << foodlist + 1 << ": Add Custom Food.";
        cout << "\n" << foodlist + 2 << ": Quit Calculator" << "\nChoice: ";
        cin >> userChoice;
        if(userChoice == foodlist + 1){
            foodlist = addfooditem(list, foodlist);
        }
        else if(userChoice<foodlist&&userChoice>0){
            choices = choices + list[userChoice-1];
            NumChoices++;
        }
        else if (userChoice < 1 || userChoice > foodlist + 2){
            cout << "\nNot a valid choice, please enter a number from the list.\n";
        }
    }
    if(NumChoices > 0){
        Results(choices);
    }
    return 0;
}