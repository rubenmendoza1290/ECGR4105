#include <iostream>

using namespace std;

class Kickball {
    public:
    Kickball(int homeruns, int kickDist, int outs);
    int
    private:
    int homeruns;
    int kickDist;
    int outs;
};

Kickball::Kickball(int homeruns, int kickDist, int outs) {
    this -> homeruns = homeruns;
    this -> kickDist = kickDist;
    this -> outs = outs;
}

Kickball()

int main(){
    Kickball
}