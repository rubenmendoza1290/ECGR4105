#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include "student.h"
using namespace std;
int main(){
    Student s1("Sam Shue");
    s1.addGrade(-1.5);
    s1.addGrade(3.0);
    s1.addGrade(1.0);
    s1.addGrade(2.0);
    
    Student s2;
    
    cout << s1.getId() << endl;
    cout << s2.getId() << endl;
    
    return 0;
}