#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <vector>
using namespace std;
class Student {
    public:
    Student();
    Student(string n);
    Student(string n, unsigned int i);
    void setName(string n);
    void addGrade(double g);
    void setId(unsigned int i);
    double getGpa() const;
    string getName() const;
    int getId() const;
    
    private:
    string name;
    unsigned int id;
    vector<double> grades;
    unsigned int getNextStudentId();
    
    static unsigned int nextId;
};
#endif