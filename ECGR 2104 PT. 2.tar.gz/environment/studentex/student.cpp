#include "student.h"
unsigned int Student::nextId = 0;
Student::Student(){
    name = "unknown";
    id = getNextStudentId();
}
Student::Student(string n){
    name = n;
    id = getNextStudentId();
}
Student::Student(string n, unsigned int i){
    name = n;
    id = i;
}
void Student::addGrade(double g){
    if(g < 0.0)
        g = 0.0;
        
    if(g > 4.0)
        g = 4.0;
        
    grades.push_back(g);
}
void Student::setName(string n){
    name = n;
}
double Student::getGpa() const {
    double sum = 0.0;
    for(int i = 0; i < grades.size(); i++){
        sum += grades.at(i);
    }
    double gpa = sum / (double)grades.size();
    
    return gpa;
}
string Student::getName() const {
    return name;
}
int Student::getId() const {
    return id;
}
void Student::setId(unsigned int i) {
    id = i;
}
unsigned int Student::getNextStudentId(){
    return ++nextId;
}