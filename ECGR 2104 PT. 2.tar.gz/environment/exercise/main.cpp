#include <iostream>

using namespace std;

class IntVector {
    public:
    IntVector();
    ~IntVector();
    IntVector(const IntVector& vectorToCopy); //copy constructor
    //looks like an overloaded constructor but different
    operator=(const IntVector& vectorToCopy);
    int size();
    int& at(int i);
    void push_back(int d);
    void pop_back();
    
    private:
    int* a = nullptr;
    //one to track size:
    int allocatedSize;
    int occupiedSize;
    const int DEFAULT_SIZE = 10; //reference here to not use magic numbers
};

IntVector::IntVector(){ //<<--constructor
    cout << "Constructor called!" << endl;
    //need to create an array of some kind of size
    //start with 10
    a = new int[DEFAULT_SIZE];
    cout << a << endl;
    //track how big array is and how much filled up:
    allocatedSize = DEFAULT_SIZE;
    occupiedSize = 0; //<<<---just when the vector is first made
    //arrays stupid don't know size
}

IntVector::~IntVector(){
    cout << "Destructor called!" << endl;
    delete [] a; //delete with brackets because a is an array
}

IntVector::IntVector(const IntVector& vectorToCopy){
    cout << "Copy constructor called!" << endl; //used to handle shadow copies
    a = new int[vectorToCopy.allocatedSize];
    allocatedSize = vectorToCopy.allocatedSize;
    occupiedSize = vectorToCopy.occupiedSize;
    
    for(int i = 0; i < occupiedSize; i++){
        a[i] = 
    }
}

int IntVector::size(){
    return occupiedSize;
}

int& IntVector::at(int i){
    return a[i];
}

void IntVector::push_back(int d){
    if(occupiedSize == allocatedSize){
        cout << "Allocating more space" << endl; //make array larger:
        allocatedSize = allocatedSize * 2; //double it in size
        int* temp = new int[allocatedSize]; //make a temporary int
        for(int i = 0; i < occupiedSize; i++){ //loop to copy variables
            temp[i] = a[i];
        }
        delete[] a;
        a = temp;
    }
    
    
    a[occupiedSize] = d;
    occupiedSize++;
}

void IntVector::pop_back(){
    if(occupiedSize <= 0)
        return;
        
    occupiedSize--;
}

void foo(){
    IntVector v;
    v.push_back(5);
    v.push_back(7);
    v.push_back(10);
    
    v.at(0) = 1;
    
    v.pop_back();
    
    for(int i = 0; i < v.size(); i++){
        cout << v.at(i) << endl;
    }
    
    IntVector b = v; //calls another type of constructor, COPY constructor
    //get called when it sees a class is being initialized
    
    IntVector z;
    
    z = v;
    
    cout << "End of foo()" << endl;
}


int main(){
    foo();
    foo();
    foo();
    
    return 0;
}