#include <iostream>

using namespace std;

class node{
public:
    int data;
    node* next;
    node* prev;
};


void printList(node*n){
    while(n!=nullptr){ //while loop to traverse each element
        cout << n->data << " ";
        n = n->next;
    }
    cout << endl;
}


//insert in front

void insertfront(node**head, int newdata){
    //1.Prepare new node
    node * newnode = new node();
    newnode->data = newdata;
    //2.Put in front of current head
    newnode->next = *head; //new node points to current head of linked list
    //3.Move head of list to point to newNode
    *head = newnode; //head of linked list will be the newly added node
}

//insert node at the end
void insertend(node**head, int newdata){
    
}


int main()
{
    //arrays vs linked
    //access vs inserting
    
    node* head = new node(); //allocating space
    node* second = new node();
    node* third = new node();
    
    //asign value and pointer 
    head->data = 1;
    head->next = second;
    second->data = 2;
    second->next = third;
    third->data = 3;
    third->next = nullptr;
    
    insertfront(&head, -1);
    insertfront(&head, -2);
    printList(head);
    
    return 0;
}