#ifndef SINGLYLINKEDLIST_H
#define SINGLYLINKEDLIST_H
#include <iostream>
#include <
template<typename T>
struct node{
    T data;
    node<T>* next = nullptr;
};
template<typename T>
class SinglyLinkedList {
    public:
    SinglyLinkedList();
    ~SinglyLinkedList();
    SinglyLinkedList(const SinglyLinkedList& objToCopy);
    
    SinglyLinkedList& operator=(const SinglyLinkedList& objToCopy);
    
    void pop();
    void push(T data);
    T& at(int index) const;
    int size() const;
    void remove(int indexToRemove);
    
    
    private:
    node<T>* head;
    int numElements;
    
};
template<typename T>
SinglyLinkedList<T>::SinglyLinkedList(){
    head = nullptr;
    numElements = 0;
}
template<typename T>
SinglyLinkedList<T>::~SinglyLinkedList(){
    std::cout << "Destructor Called!" << std::endl;
    while(numElements > 0)
        pop();
}
template<typename T>
SinglyLinkedList<T>::SinglyLinkedList(const SinglyLinkedList& objToCopy){
    std::cout << "Copy Constructor Called!" << std::endl;
    
    head = nullptr;
    numElements = 0;
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}
template<typename T>
SinglyLinkedList<T>& SinglyLinkedList<T>::operator=(const SinglyLinkedList<T>& 
objToCopy) {
    std::cout << "Copy Assignment Override Called!" << std::endl;
    
    while(numElements > 0)
        pop();
        
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}
template<typename T>
void SinglyLinkedList<T>::push(T data){
    numElements++;
    
    if(head == nullptr){
        head = new node<T>;
        head->data = data;
        return;
    }
    
    // iterate through the list to find the end
    node<T>* temp = head;
    while(temp->next != nullptr){
        temp = temp->next;
    }
    // add new node at end of chain and populate data
    temp->next = new node<T>;
    temp->next->data = data;
}
template<typename T>
void SinglyLinkedList<T>::pop(){
    if(head->next == nullptr){
        delete head;
        head = nullptr;
        numElements--;
        return;
    }
    
    node<T>* currentNode = head;
    while(currentNode->next->next != nullptr){
        currentNode = currentNode->next;
    }
    
    delete currentNode->next;
    currentNode->next = nullptr;
    numElements--;
}
template<typename T>
T& SinglyLinkedList<T>::at(int index) const{
    if(index > numElements){
        throw out_of_range("Index out of range!");
    }
    int currentIndex = 0;
    
    node<T>* currentNode = head;
    
    while(true){
        // Is current index the requested index?
        if(currentIndex == index){
            return currentNode->data;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
}
template<typename T>
int SinglyLinkedList<T>::size() const{
    /*
    int numElements = 0;
    
    if(head == nullptr){
        return numElements;
    }
    
    while(true){
        numElements++;
        if(head->next == nullptr){
            break;
        } else {
            head = head->next;
        }
    }
    
    return numElements;
    */
    return numElements;
}
template<typename T>
void SinglyLinkedList<T>::remove(int indexToRemove){
    if(indexToRemove == 0){
        node<T>* temp = head;
        if(head->next == nullptr){
            head = nullptr;
        } else {
            head = head->next;
        }
        delete temp;
        numElements--;
        return;
    }
    
    node<T>* currentNode = head;
    int currentIndex = 0;
    
    while(true){
        // Is current index 1 behind the requested index?
        if(currentIndex == (indexToRemove - 1)){
            break;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
    
    // Backup next, next node address
    node<T>* temp = currentNode->next->next;
    // Delete node to be removed
    delete currentNode->next;
    // Stitch pointers back together
    currentNode->next = temp;
    
    numElements--;
}
#endif