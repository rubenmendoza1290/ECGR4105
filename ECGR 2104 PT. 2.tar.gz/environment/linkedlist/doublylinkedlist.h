#include <iostream>
#ifndef DOUBLYLINKEDLIST_H
#define DOUBLYLINKEDLIST_H

template<typename T>
struct Node
{
    T data; //data
    Node<T> *prev; //reference to previous
    Node<T> *next; //reference to next
};

template<typename T>
class DoublyLinkedList
{
    Node<T> *head;
    Node<T> *tail;
    int numElements;
    public:
    DoublyLinkedList();
    ~DoublyLinkedList();
    
    DoublyLinkedList(const DoublyLinkedList& objToCopy);
    DoublyLinkedList& operator=(const DoublyLinkedList& objToCopy);
    
    void push(T data);
    void pop();
    int size() const;
    void print();
    T& at(int idx) const; 
    void insert(T data, int pos);
    void remove(int pos);
};

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList() {
	head = nullptr;
	tail = nullptr;
	numElements = 0;
}//end of List constructor

template<typename T>
DoublyLinkedList<T>::~DoublyLinkedList() {
	 std::cout << "Destructor Called!" << std::endl;
    while(numElements > 0)
        pop();
	}//while tail != nullptr
//end of List destructor

template<typename T>
DoublyLinkedList<T>::DoublyLinkedList(const DoublyLinkedList& objToCopy)
{
  std::cout << "Copy Constructor Called!" << std::endl;
  
    head = nullptr;
    numElements = 0;
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}

template<typename T>
DoublyLinkedList<T>& DoublyLinkedList<T>::operator=(const DoublyLinkedList<T>& objToCopy)
{
  std::cout << "Copy Assignment Override Called!" << std::endl;
    while(numElements > 0)
        pop();
        
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}

template<typename T>
void DoublyLinkedList<T>::push(T data)
{
    Node<T>* newNode = new Node<T>;
      newNode->data = data;
      newNode->next = nullptr;
      newNode->prev = nullptr; 
      if(head == nullptr) {
        head = newNode;
      } else {
        Node<T>* temp = head;
        while(temp->next != nullptr)
          temp = temp->next;
        temp->next = newNode;
        newNode->prev = temp;
      }
}

template<typename T>
void DoublyLinkedList<T>::pop()
{
    if (tail != nullptr) {
        Node<T>* temp = tail;
        tail = tail->prev;
        if (tail != nullptr) tail->next = nullptr;
        delete temp;
    }
}

template<typename T>
T& DoublyLinkedList<T>::at(int idx) const{
    int currentIndex = 0;
    
    Node<T>* currentNode = head;
    
    while(true){
        // check idx position
        if(currentIndex == idx){
            return currentNode->data;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
}

template<typename T>
int DoublyLinkedList<T>::size() const
{
    Node<int>* temp = head;
      int i = 0;
      while(temp != nullptr) {
        i++;
        temp = temp->next;
      }
      return i;
}

template<typename T>
void DoublyLinkedList<T>::print() {
      Node<T>* temp = head;
      if(temp != nullptr) {
        std::cout<<"The list contains: ";
        while(temp != nullptr) {
          std::cout<<temp->data<<" ";
          temp = temp->next;
        }
        std::cout<<std::endl;
      } else {
        std::cout<<"The list is empty.\n";
      }
    }
    
template<typename T>
void DoublyLinkedList<T>::insert(T data, int pos)
{
      Node<T>* newNode = new Node<T>;
      newNode->data = data;
      newNode->next = nullptr;
      newNode->prev = nullptr;
      if(pos < 1) {
        std::cout<<"\nposition should be >= 1.";
      } else if (pos == 1) {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
      } else {
        Node<T>* temp = head;
        for(int i = 1; i < pos-1; i++) {
          if(temp != nullptr) {
            temp = temp->next;
          }
        }
        if(temp != nullptr) {
          newNode->next = temp->next;
          newNode->prev = temp;
          temp->next = newNode;
          if(newNode->next != nullptr)
            newNode->next->prev = newNode;  
        } else {
          std::cout<<"The previous node is null.\n";
        } 
      }
    }
    
template<typename T>
void DoublyLinkedList<T>::remove(int pos) 
{     
      if(pos == 0){
        Node<T>* temp = head;
        if(head->next == nullptr){
            head = nullptr;
        } else {
            head = head->next;
        }
        delete temp;
        numElements--;
        return;
    }
    
    Node<T>* currentNode = head;
    int currentIndex = 0;
    
    while(true){
        // Is current index 1 in requested pos?
        if(currentIndex == (pos - 1)){
            break;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
    
    // Backup next, next node address
    Node<T>* temp = currentNode->next->next;
    // Delete node to be removed
    delete currentNode->next;
    // Stitch pointers back together
    currentNode->next = temp;
    
    numElements--;
}

#endif