#include "doublylinkedlist.h"

using namespace std;
DoublyLinkedList::DoublyLinkedList() {
	head = nullptr;
	tail = nullptr;
}

DoublyLinkedList::~DoublyLinkedList() {
	Node* temp = tail;
	while (tail != nullptr) {
		tail = tail->prev;
		if (tail != nullptr) tail->next = nullptr;
		delete temp;
		temp = tail;
	}//while tail != nullptr
}

DoublyLinkedList::DoublyLinkedList(const DoublyLinkedList& objToCopy)
{
    head = nullptr;
    numElements = 0;
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}

DoublyLinkedList& DoublyLinkedList::operator=(const DoublyLinkedList& objToCopy)
{
    while(numElements > 0)
        pop();
        
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}

void DoublyLinkedList::push(int newdata)
{
    Node* newNode = new Node();
      newNode->data = newdata;
      newNode->next = nullptr;
      newNode->prev = nullptr; 
      if(head == nullptr) {
        head = newNode;
      }
      else
      {
        Node* temp = head;
        while(temp->next != nullptr)
          temp = temp->next;
        temp->next = newNode;
        newNode->prev = temp;
      }
}

void DoublyLinkedList::pop()
{
    if (tail != nullptr) {
        Node* temp = tail;
        tail = tail->prev;
        if (tail != nullptr) tail->next = nullptr;
        delete temp;
    }
}

int& DoublyLinkedList::at(int idx) const
{
    int currentIndex = 0;
    
    Node* currentNode = head;
    
    while(true){
        // Is current index the requested index?
        if(currentIndex == idx){
            return currentNode->data;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
}

int DoublyLinkedList::size() const
{
    Node* temp = head;
      int i = 0;
      while(temp != NULL)
      {
        i++;
        temp = temp->next;
      }
      return i;
}

void DoublyLinkedList::print()
{
      Node* temp = head;
      if(temp != NULL)
      {
        cout << "The list contains: ";
        while(temp != NULL)
        {
          cout<<temp->data<<" ";
          temp = temp->next;
        }
        cout<<endl;
      }
      else {
        cout<<"The list is empty.\n";
      }
      return;
}
    
void DoublyLinkedList::insert(int data, int pos)
{
      Node* newNode = new Node(); 
      newNode->data = data;
      newNode->next = NULL;
      newNode->prev = NULL;
      if(pos < 1) {
        cout<<"\nposition should be >= 1.";
      }
      else if (pos == 1)
      {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
      }
      else
      {
        Node* temp = head;
        for(int i = 1; i < pos-1; i++)
        {
          if(temp != NULL)
          {
            temp = temp->next;
          }
        }
        if(temp != NULL)
        {
          newNode->next = temp->next;
          newNode->prev = temp;
          temp->next = newNode;
          if(newNode->next != NULL)
          newNode->next->prev = newNode;  
        }
        else
        {
          cout<<"The previous node is null. \n";
        }
      }
  }
    
void DoublyLinkedList::remove(int pos) 
{     
      if(pos == 0){
        Node* temp = head;
        if(head->next == nullptr){
            head = nullptr;
        } else {
            head = head->next;
        }
        delete temp;
        numElements--;
        return;
    }
    
    Node* currentNode = head;
    int currentIndex = 0;
    
    while(true){
        // Is current index 1 behind the requested index?
        if(currentIndex == (pos - 1)){
            break;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
    Node* temp = currentNode->next->next;
    // Delete node to be removed
    delete currentNode->next;
    currentNode->next = temp;
    
    numElements--;
}

