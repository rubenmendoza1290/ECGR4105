#include <iostream>
#include <queue>

using namespace std;

void printQueue(queue<int> queue)
{
    while (!queue.empty()) //while queue has elements
    {
        cout << queue.front() << " ";
        queue.pop();
    }
    cout << endl;
}

int main()
{
    //how to make a queue basically
    //the way printers work, pages will wait in a queue
    //linear queues
    //transactoins that come in very fast like online orders and stuff
    //unlike stack this is first in, first out
    queue<int> myQueue;
    myQueue.push(1);
    myQueue.push(2);
    myQueue.push(3);
    
    cout << "Size is " << myQueue.size() << endl;
    cout << "First element is " << myQueue.front() << endl;
    cout << "Last element is " << myQueue.back() << endl;
    
    cout << "My Queue: " << endl;
    printQueue(myQueue);
    
    
    return 0;
}


//TASK??program that represnts your daily schedule
//add things as you do stuff throught your day i guess