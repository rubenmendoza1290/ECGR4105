#include <iostream>
#include "doublylinkedlist.h"

using namespace std;

class Node
{
 public:
    int value;
    Node* next;
    Node* previous;
};

//1. create new node
//2. node->value = 4 set value
//3. node->next = nullptr //take care of next pointer
//node->previous = nullptr //previous pointer
//4. head = node
//5. tail = node


void printForward(Node*head)
{
    Node* traverser = head;
    while (traverser != nullptr) {
        cout << traverser->value <<endl;
        traverser = traverser->next;
    }
}


void printBackward(Node* tail)
{
    Node* traverser = tail;
    while (traverser != nullptr) {
        cout << traverser->value << endl;
        traverser = traverser->previous;
    }
}


int main()
{
//advantage:
//1. can go forward or backward
//2. can add new nodes faster than singly linked
//disadvantage
//a bit more complicated 
    Node* head;
    Node* tail;
    //add 1st node
    Node* node = new Node();
    node->value = 4;
    node->next = nullptr;
    node->previous = nullptr;
    head = node;
    tail = node;
    //add 2nd node
    node = new Node();
    node->value = 5;
    node->next = nullptr;
    node->previous = tail;
    tail->next = node;
    tail = node;
    //add 3rd node
    node = new Node();
    node->value = 6;
    node->next = nullptr;
    node->previous = tail;
    tail->next = node;
    tail = node;
    //add 4th node
    node = new Node();
    node->value = 7;
    node->next = nullptr;
    node->previous = tail;
    tail->next = node;
    tail = node;
    
    printForward(head);
    
    
    
    //cin.get();
}