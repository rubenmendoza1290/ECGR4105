#include <iostream>

using namespace std;

int main(){
    //total average, inTwoYears
   /* float month1 = 100;
    float month2 = 220;
    float month3 = 300;
    float month4 = 0;
    float month5 = 200;
    float month6 = 250;
    */
    float monthsArray[12];// = {100,220,300,0,200,250};
                           //0   1   2  3  4   5 
    float total = 0;
    for(int i=0; i<=11;i++){
        cout << "Enter amount for month " << i+1 << ": ";
        cin >> monthsArray[i];
        total += monthsArray[i];
        
    }
    float avg = total / 12;
    float inTwoYears = avg *24;
    
    cout << "total = " << total << endl;
    cout << "average = " << avg <<endl;
    cout << "inTwoYears = " << inTwoYears << endl;
    
    
    return 0;
}