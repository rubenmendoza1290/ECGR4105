#include <iostream>

using namespace std;


//each element consist two parts
//address and element
//sumn like dat^
//using a class in order to represent one element of set
//node is a
class Node{
    public: //this makes it public
    int Value;
    Node* Next; //these are private by default
};

void printList(Node*n) {
    //needs to receive first element (head)
    //once we come to null we know its the last element
    while(n != NULL) {
        cout << n->Value << endl;
        n = n->Next;
    }
}


int main()
{
    Node* head = new Node();//"head" means first element of a linked list
    Node* second = new Node();
    Node* third = new Node();
    
    
    head->Value = 1;
    head->Next = second; //first (head) points to second
    second->Value = 2;
    second->Next = third;
    third-> Value = 3;
    third->Next = NULL;
    
    printList(head);
    
    return 0;
}