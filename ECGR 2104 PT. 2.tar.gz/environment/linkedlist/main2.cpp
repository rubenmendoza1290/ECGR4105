#include <iostream>
#include "singlylinkedlist.h"
using namespace std;
void foo(){
    SinglyLinkedList<int> sll;
    
    sll.push(1);
    sll.push(2);
    sll.push(3);
    
    sll.remove(0);
    
    cout << "Size: " << sll.size() << endl;
    
    for(int i = 0; i < sll.size(); i++){
        cout << sll.at(i) << endl;
    }
    
    SinglyLinkedList<int> sll2 = sll;
    
    SinglyLinkedList<int> sll3;
    
    sll3.push(20);
    sll3.push(10);
    
    sll3 = sll;
    
    SinglyLinkedList<float>* sllp = new SinglyLinkedList<float>;
    sllp->push(2.2);
    sllp->push(5.6);
    
    delete sllp;
}
int main(){
   
    foo();
    foo();
    
    return 0;
}