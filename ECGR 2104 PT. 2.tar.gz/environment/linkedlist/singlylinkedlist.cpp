#include "singlylinkedlist.h"
SinglyLinkedList::SinglyLinkedList(){
    head = nullptr;
    numElements = 0;
}
SinglyLinkedList::~SinglyLinkedList(){
    std::cout << "Destructor Called!" << std::endl;
    while(numElements > 0)
        pop();
}
SinglyLinkedList::SinglyLinkedList(const SinglyLinkedList& objToCopy){
    std::cout << "Copy Constructor Called!" << std::endl;
    
    head = nullptr;
    numElements = 0;
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}
SinglyLinkedList& SinglyLinkedList::operator=(const SinglyLinkedList& objToCopy) {
    std::cout << "Copy Assignment Override Called!" << std::endl;
    
    while(numElements > 0)
        pop();
        
    for(int i = 0; i < objToCopy.size(); i++){
        push(objToCopy.at(i));
    }
}
void SinglyLinkedList::push(int data){
    numElements++;
    
    if(head == nullptr){
        head = new node;
        head->data = data;
        return;
    }
    
    // iterate through the list to find the end
    node* temp = head;
    while(temp->next != nullptr){
        temp = temp->next;
    }
    // add new node at end of chain and populate data
    temp->next = new node;
    temp->next->data = data;
}
void SinglyLinkedList::pop(){
    if(head->next == nullptr){
        delete head;
        head = nullptr;
        numElements--;
        return;
    }
    
    node* currentNode = head;
    while(currentNode->next->next != nullptr){
        currentNode = currentNode->next;
    }
    
    delete currentNode->next;
    currentNode->next = nullptr;
    numElements--;
}
int& SinglyLinkedList::at(int index) const{
    int currentIndex = 0;
    
    node* currentNode = head;
    
    while(true){
        // Is current index the requested index?
        if(currentIndex == index){
            return currentNode->data;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
}
int SinglyLinkedList::size() const{
    /*
    int numElements = 0;
    
    if(head == nullptr){
        return numElements;
    }
    
    while(true){
        numElements++;
        if(head->next == nullptr){
            break;
        } else {
            head = head->next;
        }
    }
    
    return numElements;
    */
    return numElements;
}
void SinglyLinkedList::remove(int indexToRemove){
    if(indexToRemove == 0){
        node* temp = head;
        if(head->next == nullptr){
            head = nullptr;
        } else {
            head = head->next;
        }
        delete temp;
        numElements--;
        return;
    }
    
    node* currentNode = head;
    int currentIndex = 0;
    
    while(true){
        // Is current index 1 behind the requested index?
        if(currentIndex == (indexToRemove - 1)){
            break;
        }
        
        // Crawl to next element
        currentIndex++;
        currentNode = currentNode->next;
    }
    
    // Backup next, next node address
    node* temp = currentNode->next->next;
    // Delete node to be removed
    delete currentNode->next;
    // Stitch pointers back together
    currentNode->next = temp;
    
    numElements--;
}