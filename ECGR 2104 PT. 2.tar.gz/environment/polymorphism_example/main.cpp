#include <iostream>

using namespace std;

class Shape {
    public:
    Shape(double w, double h){
        cout << "Shape constructor called" << endl;
        width = w;
        height = h;
    }
    
    void print(){
        cout << "Called from the Shape class" << endl;
        cout << "w: " << width << endl << "h: " << height << endl;
    }
    
    double area(){
        return width * height;
    }
    
    protected:
    double width;
    double height;
};

class Square : public Shape {
    public:
    Square(double s) : Shape(s, s){
    }
    
    void print(){
        cout << "Called from Square class" << endl;
        cout << "w: " << width << endl;
    }
};


class Triangle : public Shape {
    public:
    Triangle(double b, double h) : Shape(b, h){
        
    }
    
    double area(){
        return 0.5 * width * height;
    }
    
};

int main(){
    
    Shape rectangle(5.0, 2.0);
    rectangle.print();
    cout << rectangle.area() << endl;
    
    Square square(2.0);
    square.print();
    cout << square.area() << endl;
    
    Triangle triangle(5.0, 5.0);
    triangle.print();
    cout << triangle.area() << endl;
    
    
    return 0;
}