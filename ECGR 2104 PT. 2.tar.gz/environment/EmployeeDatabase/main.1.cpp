#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Book{
    public:
    string GetName() const;
    int GetISBN() const;
    void Print() const;
    private:
        string name;
        double ISBN;
};
string Book::GetName() const{
    return name;
}
int Book::GetISBN() const{
    return ISBN;
}
void Book::Print() const{
    cout << name << endl;
}

int main(){
    
    int UserChoice;
    //int Hours;
    //string Newname;
    vector<string> title = {"The Shining", "Pet Semetary", "To Kill a Mockingbird", "Go set a watchman" };
    vector<string> names = {"Stephen King", "Stephen King", "Harper Lee", "Harper Lee"};
    vector<double> ISBN = {1001, 1002, 1003, 1004};
    
    
    while(UserChoice != 4){
    cout << "Hello! Welcome to the Book Data Base. Here you have the ability to search the database\n" << endl;
    cout << "Please choose an option to Search: \n" << endl;
    cout << "1. Author\n2. ISBN\n3. Title\n4. Exit application" << endl;
    cin >> UserChoice;
    while(UserChoice != 4){
    if (UserChoice == 1){
        cout << "please enter author name" << endl;
        cin >> namesearch;
        for(int i = 0; i < names.size(); i++){ //don't want to go outside number of string in i < n
        cout << names.at(i) << "\n" << endl; //.at(i) returns some reference, does same thing as [i] which is direct access to where it is
        //whenever using vectors, safer to use .at(i)
        //cout << payRate.at(i) << endl;
    }
        break;
    }
    else if (UserChoice == 2){
        for(int i = 0; i < ISBN.size(); i++){ //don't want to go outside number of string in i < n
        cout << ISBN.at(i) << "\n" << endl; 
        break;
    }
    else if (UserChoice == 3){
        for(int i = 0; i < title.size(); i++){ //don't want to go outside number of string in i < n
        cout << title.at(i) << "\n" << endl; 
        break;
    }
    else {
        cout << "please choose an option from the list: \n" << endl;
        break;
    }
    }
    }
    return 0;
}