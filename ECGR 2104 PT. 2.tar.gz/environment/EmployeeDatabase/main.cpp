#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Employee{
    public:
    void setName(string EmployeeName);
    void setHourlyWage(int userHourlyWageInput);
    string GetName() const;
    int GetHourlyWage() const;
    void Print() const;
    private:
        string name;
        int HourlyWage;
};
void Employee::setName(string EmployeeName){
    name = EmployeeName;
}
string Employee::GetName() const{
    return name;
}
int Employee::GetHourlyWage() const{
    return HourlyWage;
}
void Employee::Print() const{
    cout << name << endl;
}

int main(){
    
    int UserChoice;
    int Hours;
    string Newname;
    vector<string> names = {"Samuel Samuelson", "Yousef Yousefson", "Phil Cole"};
    vector<double> payRate = {15.0, 15.0, 15.0};
    
    
    while(UserChoice != 4){
    cout << "Hello! Welcome to the Employee Data Base. Here you have access to the emplyee list, calculate wages, and add a new employee\n" << endl;
    cout << "Please choose an option: \n" << endl;
    cout << "1. Print list of employees\n2. Calculate total wages\n3. Add new employee\n4. Exit application" << endl;
    cin >> UserChoice;
    while(UserChoice != 4){
    if (UserChoice == 1){
        for(int i = 0; i < names.size(); i++){ //don't want to go outside number of string in i < n
        cout << names.at(i) << "\n" << endl; //.at(i) returns some reference, does same thing as [i] which is direct access to where it is
        //whenever using vectors, safer to use .at(i)
        //cout << payRate.at(i) << endl;
    }
        break;
    }
    else if (UserChoice == 2){
        cout << "Enter number of Hours:\n" << endl;
        cin >> Hours;
        cout << "Total Pay for this week is: $" << Hours * 15 << endl;
        break;
    }
    else if (UserChoice == 3){
        Employee myEmployee;
        cout << "Enter new employee name: \n" << endl;
            cin >> Newname;
            names.push_back (Newname);
        break;
    }
    else {
        cout << "please choose an option from the list: \n" << endl;
        break;
    }
    }
    }
    return 0;
}