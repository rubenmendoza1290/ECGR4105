#include<iostream>

using namespace std;

int main(){
int x = 55;
int y = 42;
int* ptr = &x;
ptr = &y;
cout << &ptr << endl;
cout << "address of y " << &y << endl;
cout << "address of x " << &x << endl;
    return 0;
}