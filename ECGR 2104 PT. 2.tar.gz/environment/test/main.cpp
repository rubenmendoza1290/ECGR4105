#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
// -f filename -> specifies "filename" as the file to open
// -v -> verbose flag
int main(int argc, char* argv[]){
    string filename;
    bool debug = false;
    
    for(int i = 0; i < argc; i++){
        if(strcmp(argv[i],"-f") == 0){
            if(i + 1 < argc){
                filename = argv[i + 1];
            } else {
                cout << "No filename specified" << endl;
                return 0;
            }
        }
        
        if(strcmp(argv[i],"-v") == 0){
            debug = true;
        }
    }
    
    if(debug) cout << filename << endl;
    
    ofstream outFile;
    
    outFile.open(filename);
    
    outFile << "Hello World!" << endl;
    outFile << "Hello World!" << endl;
    outFile << "Hello World!" << endl;
    outFile << "Hello World!" << endl;
    
    outFile.close();
    
    ifstream inFile;
    
    inFile.open(filename);
    
    string contents;
    string temp;
    while(!inFile.eof()){
        getline(inFile, temp);
        contents += temp;
        contents += '\n';
    }
    
    inFile.close();
    
    cout << contents << endl;
    
    return 0;
}