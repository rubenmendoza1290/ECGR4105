# survivalgame
text based c++ survival game
