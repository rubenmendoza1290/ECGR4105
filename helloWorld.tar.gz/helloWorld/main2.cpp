#include <iostream>
using namespace std;

int main()
{
    int myAge = 20;
    cout << "I am " << myAge << " years old. \n";
    return 0;
}