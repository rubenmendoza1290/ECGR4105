#include<iostream>

using namespace std;

int main(){
int x = 55;
int y = 42;
int* ptr = &x;
ptr = &y;
cout << ptr << endl;
    return 0;
}