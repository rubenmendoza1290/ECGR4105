#include <iostream>
using namespace std;

int main () {
    
    int myNum = 13;                     // Whole number w/o decimals
    double myFloatNum = 2.34;           // Floating point number with decimals
    char myLetter = 'D';                // Character
    string myText = "AMERICA FIRST";    // String(text)
    bool myBoolean = true;              // Boolean (true or false)
    
    cout << myLetter << "\n";
    cout << myFloatNum << "\n";
    cout << myNum << "\n";
    cout << myText << "\n";
    cout << myBoolean << "\n";
    
    return 0;
}