#include <iostream>
using namespace std;

int main()
{
    int x = 8, y = 23, z = 43;
    cout << x + y + z << endl;
    return 0;
    
}