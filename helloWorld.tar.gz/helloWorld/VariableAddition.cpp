#include <iostream>
using namespace std;

int main()
{
    int x = 20;
    int y = 21;
    int sum = x +y;
    cout << sum <<endl;
    
    return 0;
}